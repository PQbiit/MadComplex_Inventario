﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class treatments
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnhome = New System.Windows.Forms.Button
        Me.lblchocolate = New System.Windows.Forms.Label
        Me.lblpricechocolate = New System.Windows.Forms.Label
        Me.nudchocolate = New System.Windows.Forms.NumericUpDown
        Me.lbluniqone = New System.Windows.Forms.Label
        Me.lblpriceuniqone = New System.Windows.Forms.Label
        Me.nuduniqone = New System.Windows.Forms.NumericUpDown
        Me.lblfacetwo = New System.Windows.Forms.Label
        Me.lblpricefacetwo = New System.Windows.Forms.Label
        Me.nudfacetwo = New System.Windows.Forms.NumericUpDown
        Me.lblvitamin = New System.Windows.Forms.Label
        Me.lblpricevitamin = New System.Windows.Forms.Label
        Me.nudkeratin = New System.Windows.Forms.NumericUpDown
        Me.nudextensions = New System.Windows.Forms.NumericUpDown
        Me.nudvitamin = New System.Windows.Forms.NumericUpDown
        Me.lblkeratin = New System.Windows.Forms.Label
        Me.lblextensions = New System.Windows.Forms.Label
        Me.lblpriceextensions = New System.Windows.Forms.Label
        Me.lblpricekeratin = New System.Windows.Forms.Label
        CType(Me.nudchocolate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nuduniqone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudfacetwo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudkeratin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudextensions, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudvitamin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnhome
        '
        Me.btnhome.Font = New System.Drawing.Font("KG Change This Heart", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhome.ForeColor = System.Drawing.Color.Purple
        Me.btnhome.Location = New System.Drawing.Point(751, 472)
        Me.btnhome.Name = "btnhome"
        Me.btnhome.Size = New System.Drawing.Size(140, 31)
        Me.btnhome.TabIndex = 30
        Me.btnhome.Text = "HOME"
        Me.btnhome.UseVisualStyleBackColor = True
        '
        'lblchocolate
        '
        Me.lblchocolate.AutoSize = True
        Me.lblchocolate.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblchocolate.ForeColor = System.Drawing.Color.Purple
        Me.lblchocolate.Location = New System.Drawing.Point(45, 33)
        Me.lblchocolate.Name = "lblchocolate"
        Me.lblchocolate.Size = New System.Drawing.Size(300, 33)
        Me.lblchocolate.TabIndex = 32
        Me.lblchocolate.Text = "Chocolate Treatment"
        '
        'lblpricechocolate
        '
        Me.lblpricechocolate.AutoSize = True
        Me.lblpricechocolate.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricechocolate.ForeColor = System.Drawing.Color.Red
        Me.lblpricechocolate.Location = New System.Drawing.Point(112, 79)
        Me.lblpricechocolate.Name = "lblpricechocolate"
        Me.lblpricechocolate.Size = New System.Drawing.Size(125, 44)
        Me.lblpricechocolate.TabIndex = 35
        Me.lblpricechocolate.Text = "$1000"
        '
        'nudchocolate
        '
        Me.nudchocolate.Location = New System.Drawing.Point(120, 137)
        Me.nudchocolate.Name = "nudchocolate"
        Me.nudchocolate.Size = New System.Drawing.Size(120, 20)
        Me.nudchocolate.TabIndex = 36
        '
        'lbluniqone
        '
        Me.lbluniqone.AutoSize = True
        Me.lbluniqone.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbluniqone.ForeColor = System.Drawing.Color.Purple
        Me.lbluniqone.Location = New System.Drawing.Point(114, 204)
        Me.lbluniqone.Name = "lbluniqone"
        Me.lbluniqone.Size = New System.Drawing.Size(143, 33)
        Me.lbluniqone.TabIndex = 37
        Me.lbluniqone.Text = "Uniq One "
        '
        'lblpriceuniqone
        '
        Me.lblpriceuniqone.AutoSize = True
        Me.lblpriceuniqone.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceuniqone.ForeColor = System.Drawing.Color.Red
        Me.lblpriceuniqone.Location = New System.Drawing.Point(124, 245)
        Me.lblpriceuniqone.Name = "lblpriceuniqone"
        Me.lblpriceuniqone.Size = New System.Drawing.Size(104, 44)
        Me.lblpriceuniqone.TabIndex = 38
        Me.lblpriceuniqone.Text = "$300"
        '
        'nuduniqone
        '
        Me.nuduniqone.Location = New System.Drawing.Point(120, 301)
        Me.nuduniqone.Name = "nuduniqone"
        Me.nuduniqone.Size = New System.Drawing.Size(120, 20)
        Me.nuduniqone.TabIndex = 39
        '
        'lblfacetwo
        '
        Me.lblfacetwo.AutoSize = True
        Me.lblfacetwo.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfacetwo.ForeColor = System.Drawing.Color.Purple
        Me.lblfacetwo.Location = New System.Drawing.Point(114, 373)
        Me.lblfacetwo.Name = "lblfacetwo"
        Me.lblfacetwo.Size = New System.Drawing.Size(141, 33)
        Me.lblfacetwo.TabIndex = 40
        Me.lblfacetwo.Text = "Face Two"
        '
        'lblpricefacetwo
        '
        Me.lblpricefacetwo.AutoSize = True
        Me.lblpricefacetwo.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricefacetwo.ForeColor = System.Drawing.Color.Red
        Me.lblpricefacetwo.Location = New System.Drawing.Point(135, 419)
        Me.lblpricefacetwo.Name = "lblpricefacetwo"
        Me.lblpricefacetwo.Size = New System.Drawing.Size(104, 44)
        Me.lblpricefacetwo.TabIndex = 41
        Me.lblpricefacetwo.Text = "$220"
        '
        'nudfacetwo
        '
        Me.nudfacetwo.Location = New System.Drawing.Point(120, 477)
        Me.nudfacetwo.Name = "nudfacetwo"
        Me.nudfacetwo.Size = New System.Drawing.Size(120, 20)
        Me.nudfacetwo.TabIndex = 42
        '
        'lblvitamin
        '
        Me.lblvitamin.AutoSize = True
        Me.lblvitamin.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblvitamin.ForeColor = System.Drawing.Color.Purple
        Me.lblvitamin.Location = New System.Drawing.Point(582, 33)
        Me.lblvitamin.Name = "lblvitamin"
        Me.lblvitamin.Size = New System.Drawing.Size(137, 33)
        Me.lblvitamin.TabIndex = 43
        Me.lblvitamin.Text = "Vitamin E"
        '
        'lblpricevitamin
        '
        Me.lblpricevitamin.AutoSize = True
        Me.lblpricevitamin.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricevitamin.ForeColor = System.Drawing.Color.Red
        Me.lblpricevitamin.Location = New System.Drawing.Point(599, 79)
        Me.lblpricevitamin.Name = "lblpricevitamin"
        Me.lblpricevitamin.Size = New System.Drawing.Size(104, 44)
        Me.lblpricevitamin.TabIndex = 44
        Me.lblpricevitamin.Text = "$160"
        '
        'nudkeratin
        '
        Me.nudkeratin.Location = New System.Drawing.Point(599, 477)
        Me.nudkeratin.Name = "nudkeratin"
        Me.nudkeratin.Size = New System.Drawing.Size(120, 20)
        Me.nudkeratin.TabIndex = 45
        '
        'nudextensions
        '
        Me.nudextensions.Location = New System.Drawing.Point(599, 301)
        Me.nudextensions.Name = "nudextensions"
        Me.nudextensions.Size = New System.Drawing.Size(120, 20)
        Me.nudextensions.TabIndex = 46
        '
        'nudvitamin
        '
        Me.nudvitamin.Location = New System.Drawing.Point(599, 137)
        Me.nudvitamin.Name = "nudvitamin"
        Me.nudvitamin.Size = New System.Drawing.Size(120, 20)
        Me.nudvitamin.TabIndex = 47
        '
        'lblkeratin
        '
        Me.lblkeratin.AutoSize = True
        Me.lblkeratin.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblkeratin.ForeColor = System.Drawing.Color.Purple
        Me.lblkeratin.Location = New System.Drawing.Point(601, 373)
        Me.lblkeratin.Name = "lblkeratin"
        Me.lblkeratin.Size = New System.Drawing.Size(107, 33)
        Me.lblkeratin.TabIndex = 48
        Me.lblkeratin.Text = "Keratin"
        '
        'lblextensions
        '
        Me.lblextensions.AutoSize = True
        Me.lblextensions.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblextensions.ForeColor = System.Drawing.Color.Purple
        Me.lblextensions.Location = New System.Drawing.Point(546, 204)
        Me.lblextensions.Name = "lblextensions"
        Me.lblextensions.Size = New System.Drawing.Size(231, 33)
        Me.lblextensions.TabIndex = 49
        Me.lblextensions.Text = "Feeds Extensions"
        '
        'lblpriceextensions
        '
        Me.lblpriceextensions.AutoSize = True
        Me.lblpriceextensions.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceextensions.ForeColor = System.Drawing.Color.Red
        Me.lblpriceextensions.Location = New System.Drawing.Point(599, 245)
        Me.lblpriceextensions.Name = "lblpriceextensions"
        Me.lblpriceextensions.Size = New System.Drawing.Size(104, 44)
        Me.lblpriceextensions.TabIndex = 50
        Me.lblpriceextensions.Text = "$160"
        '
        'lblpricekeratin
        '
        Me.lblpricekeratin.AutoSize = True
        Me.lblpricekeratin.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricekeratin.ForeColor = System.Drawing.Color.Red
        Me.lblpricekeratin.Location = New System.Drawing.Point(599, 419)
        Me.lblpricekeratin.Name = "lblpricekeratin"
        Me.lblpricekeratin.Size = New System.Drawing.Size(104, 44)
        Me.lblpricekeratin.TabIndex = 51
        Me.lblpricekeratin.Text = "$160"
        '
        'treatments
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(893, 506)
        Me.Controls.Add(Me.lblpricekeratin)
        Me.Controls.Add(Me.lblpriceextensions)
        Me.Controls.Add(Me.lblextensions)
        Me.Controls.Add(Me.lblkeratin)
        Me.Controls.Add(Me.nudvitamin)
        Me.Controls.Add(Me.nudextensions)
        Me.Controls.Add(Me.nudkeratin)
        Me.Controls.Add(Me.lblpricevitamin)
        Me.Controls.Add(Me.lblvitamin)
        Me.Controls.Add(Me.nudfacetwo)
        Me.Controls.Add(Me.lblpricefacetwo)
        Me.Controls.Add(Me.lblfacetwo)
        Me.Controls.Add(Me.nuduniqone)
        Me.Controls.Add(Me.lblpriceuniqone)
        Me.Controls.Add(Me.lbluniqone)
        Me.Controls.Add(Me.nudchocolate)
        Me.Controls.Add(Me.lblpricechocolate)
        Me.Controls.Add(Me.lblchocolate)
        Me.Controls.Add(Me.btnhome)
        Me.Name = "treatments"
        Me.Text = "treatments"
        CType(Me.nudchocolate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nuduniqone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudfacetwo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudkeratin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudextensions, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudvitamin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnhome As System.Windows.Forms.Button
    Friend WithEvents lblchocolate As System.Windows.Forms.Label
    Friend WithEvents lblpricechocolate As System.Windows.Forms.Label
    Friend WithEvents nudchocolate As System.Windows.Forms.NumericUpDown
    Friend WithEvents lbluniqone As System.Windows.Forms.Label
    Friend WithEvents lblpriceuniqone As System.Windows.Forms.Label
    Friend WithEvents nuduniqone As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblfacetwo As System.Windows.Forms.Label
    Friend WithEvents lblpricefacetwo As System.Windows.Forms.Label
    Friend WithEvents nudfacetwo As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblvitamin As System.Windows.Forms.Label
    Friend WithEvents lblpricevitamin As System.Windows.Forms.Label
    Friend WithEvents nudkeratin As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudextensions As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudvitamin As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblkeratin As System.Windows.Forms.Label
    Friend WithEvents lblextensions As System.Windows.Forms.Label
    Friend WithEvents lblpriceextensions As System.Windows.Forms.Label
    Friend WithEvents lblpricekeratin As System.Windows.Forms.Label
End Class
