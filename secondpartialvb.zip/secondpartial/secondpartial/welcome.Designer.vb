﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Kbs = New System.Windows.Forms.Label
        Me.welcome = New System.Windows.Forms.Label
        Me.btnhair = New System.Windows.Forms.Button
        Me.btntreat = New System.Windows.Forms.Button
        Me.btnfacials = New System.Windows.Forms.Button
        Me.btnspa = New System.Windows.Forms.Button
        Me.btnaccount = New System.Windows.Forms.Button
        Me.btninventory = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Kbs
        '
        Me.Kbs.AutoSize = True
        Me.Kbs.Font = New System.Drawing.Font("KG Change This Heart", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Kbs.ForeColor = System.Drawing.Color.Purple
        Me.Kbs.Location = New System.Drawing.Point(190, 31)
        Me.Kbs.Name = "Kbs"
        Me.Kbs.Size = New System.Drawing.Size(543, 47)
        Me.Kbs.TabIndex = 0
        Me.Kbs.Text = "Karol's Beauty Salon "
        '
        'welcome
        '
        Me.welcome.AutoSize = True
        Me.welcome.Font = New System.Drawing.Font("KG Change This Heart", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.welcome.ForeColor = System.Drawing.Color.Purple
        Me.welcome.Location = New System.Drawing.Point(309, 78)
        Me.welcome.Name = "welcome"
        Me.welcome.Size = New System.Drawing.Size(204, 31)
        Me.welcome.TabIndex = 1
        Me.welcome.Text = "WELCOME"
        '
        'btnhair
        '
        Me.btnhair.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhair.Location = New System.Drawing.Point(315, 167)
        Me.btnhair.Name = "btnhair"
        Me.btnhair.Size = New System.Drawing.Size(209, 53)
        Me.btnhair.TabIndex = 2
        Me.btnhair.Text = "Hair Services"
        Me.btnhair.UseVisualStyleBackColor = True
        '
        'btntreat
        '
        Me.btntreat.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntreat.Location = New System.Drawing.Point(315, 344)
        Me.btntreat.Name = "btntreat"
        Me.btntreat.Size = New System.Drawing.Size(209, 53)
        Me.btntreat.TabIndex = 3
        Me.btntreat.Text = "Treatments"
        Me.btntreat.UseVisualStyleBackColor = True
        '
        'btnfacials
        '
        Me.btnfacials.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnfacials.Location = New System.Drawing.Point(315, 226)
        Me.btnfacials.Name = "btnfacials"
        Me.btnfacials.Size = New System.Drawing.Size(209, 53)
        Me.btnfacials.TabIndex = 4
        Me.btnfacials.Text = "Facials"
        Me.btnfacials.UseVisualStyleBackColor = True
        '
        'btnspa
        '
        Me.btnspa.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnspa.Location = New System.Drawing.Point(315, 285)
        Me.btnspa.Name = "btnspa"
        Me.btnspa.Size = New System.Drawing.Size(209, 53)
        Me.btnspa.TabIndex = 5
        Me.btnspa.Text = "SPA"
        Me.btnspa.UseVisualStyleBackColor = True
        '
        'btnaccount
        '
        Me.btnaccount.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnaccount.Location = New System.Drawing.Point(723, 418)
        Me.btnaccount.Name = "btnaccount"
        Me.btnaccount.Size = New System.Drawing.Size(154, 47)
        Me.btnaccount.TabIndex = 6
        Me.btnaccount.Text = "Accounting"
        Me.btnaccount.UseVisualStyleBackColor = True
        '
        'btninventory
        '
        Me.btninventory.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btninventory.Location = New System.Drawing.Point(723, 365)
        Me.btninventory.Name = "btninventory"
        Me.btninventory.Size = New System.Drawing.Size(154, 47)
        Me.btninventory.TabIndex = 7
        Me.btninventory.Text = "Inventory"
        Me.btninventory.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.MenuBar
        Me.ClientSize = New System.Drawing.Size(891, 502)
        Me.Controls.Add(Me.btninventory)
        Me.Controls.Add(Me.btnaccount)
        Me.Controls.Add(Me.btnspa)
        Me.Controls.Add(Me.btnfacials)
        Me.Controls.Add(Me.btntreat)
        Me.Controls.Add(Me.btnhair)
        Me.Controls.Add(Me.welcome)
        Me.Controls.Add(Me.Kbs)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Form1"
        Me.Text = "services"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Kbs As System.Windows.Forms.Label
    Friend WithEvents welcome As System.Windows.Forms.Label
    Friend WithEvents btnhair As System.Windows.Forms.Button
    Friend WithEvents btntreat As System.Windows.Forms.Button
    Friend WithEvents btnfacials As System.Windows.Forms.Button
    Friend WithEvents btnspa As System.Windows.Forms.Button
    Friend WithEvents btnaccount As System.Windows.Forms.Button
    Friend WithEvents btninventory As System.Windows.Forms.Button

End Class
