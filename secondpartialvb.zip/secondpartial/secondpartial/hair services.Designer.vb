﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class hair_services
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblgentleman = New System.Windows.Forms.Label
        Me.lbllady = New System.Windows.Forms.Label
        Me.lblpricegentleman = New System.Windows.Forms.Label
        Me.lblpricelady = New System.Windows.Forms.Label
        Me.nudgentleman = New System.Windows.Forms.NumericUpDown
        Me.lblhairstyle = New System.Windows.Forms.Label
        Me.lbldried = New System.Windows.Forms.Label
        Me.lblironing = New System.Windows.Forms.Label
        Me.lbllights = New System.Windows.Forms.Label
        Me.lblwicks = New System.Windows.Forms.Label
        Me.lbldyes = New System.Windows.Forms.Label
        Me.lblpermanent = New System.Windows.Forms.Label
        Me.lblpricedried = New System.Windows.Forms.Label
        Me.lblpricewicks = New System.Windows.Forms.Label
        Me.lblpricelights = New System.Windows.Forms.Label
        Me.lblpricepermanent = New System.Windows.Forms.Label
        Me.lblpricedyes = New System.Windows.Forms.Label
        Me.lblpriceironing = New System.Windows.Forms.Label
        Me.lblpricehairstyle = New System.Windows.Forms.Label
        Me.nudlady = New System.Windows.Forms.NumericUpDown
        Me.nuddried = New System.Windows.Forms.NumericUpDown
        Me.nuddyes = New System.Windows.Forms.NumericUpDown
        Me.nudpermanent = New System.Windows.Forms.NumericUpDown
        Me.nudwicks = New System.Windows.Forms.NumericUpDown
        Me.nudlights = New System.Windows.Forms.NumericUpDown
        Me.nudironing = New System.Windows.Forms.NumericUpDown
        Me.nudhairstyle = New System.Windows.Forms.NumericUpDown
        Me.btnhome = New System.Windows.Forms.Button
        CType(Me.nudgentleman, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudlady, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nuddried, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nuddyes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudpermanent, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudwicks, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudlights, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudironing, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudhairstyle, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblgentleman
        '
        Me.lblgentleman.AutoSize = True
        Me.lblgentleman.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgentleman.ForeColor = System.Drawing.Color.Purple
        Me.lblgentleman.Location = New System.Drawing.Point(12, 9)
        Me.lblgentleman.Name = "lblgentleman"
        Me.lblgentleman.Size = New System.Drawing.Size(279, 33)
        Me.lblgentleman.TabIndex = 0
        Me.lblgentleman.Text = "Gentleman Hair Cut"
        '
        'lbllady
        '
        Me.lbllady.AutoSize = True
        Me.lbllady.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllady.ForeColor = System.Drawing.Color.Purple
        Me.lbllady.Location = New System.Drawing.Point(48, 167)
        Me.lbllady.Name = "lbllady"
        Me.lbllady.Size = New System.Drawing.Size(191, 33)
        Me.lbllady.TabIndex = 1
        Me.lbllady.Text = "Lady Hair Cut"
        '
        'lblpricegentleman
        '
        Me.lblpricegentleman.AutoSize = True
        Me.lblpricegentleman.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricegentleman.ForeColor = System.Drawing.Color.Red
        Me.lblpricegentleman.Location = New System.Drawing.Point(94, 51)
        Me.lblpricegentleman.Name = "lblpricegentleman"
        Me.lblpricegentleman.Size = New System.Drawing.Size(83, 44)
        Me.lblpricegentleman.TabIndex = 2
        Me.lblpricegentleman.Text = "$50"
        '
        'lblpricelady
        '
        Me.lblpricelady.AutoSize = True
        Me.lblpricelady.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricelady.ForeColor = System.Drawing.Color.Red
        Me.lblpricelady.Location = New System.Drawing.Point(94, 210)
        Me.lblpricelady.Name = "lblpricelady"
        Me.lblpricelady.Size = New System.Drawing.Size(104, 44)
        Me.lblpricelady.TabIndex = 3
        Me.lblpricelady.Text = "$100"
        '
        'nudgentleman
        '
        Me.nudgentleman.Location = New System.Drawing.Point(69, 98)
        Me.nudgentleman.Name = "nudgentleman"
        Me.nudgentleman.Size = New System.Drawing.Size(139, 20)
        Me.nudgentleman.TabIndex = 4
        '
        'lblhairstyle
        '
        Me.lblhairstyle.AutoSize = True
        Me.lblhairstyle.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhairstyle.ForeColor = System.Drawing.Color.Purple
        Me.lblhairstyle.Location = New System.Drawing.Point(74, 330)
        Me.lblhairstyle.Name = "lblhairstyle"
        Me.lblhairstyle.Size = New System.Drawing.Size(134, 33)
        Me.lblhairstyle.TabIndex = 5
        Me.lblhairstyle.Text = "Hair Style"
        '
        'lbldried
        '
        Me.lbldried.AutoSize = True
        Me.lbldried.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldried.ForeColor = System.Drawing.Color.Purple
        Me.lbldried.Location = New System.Drawing.Point(402, 167)
        Me.lbldried.Name = "lbldried"
        Me.lbldried.Size = New System.Drawing.Size(86, 33)
        Me.lbldried.TabIndex = 6
        Me.lbldried.Text = "Dried"
        '
        'lblironing
        '
        Me.lblironing.AutoSize = True
        Me.lblironing.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblironing.ForeColor = System.Drawing.Color.Purple
        Me.lblironing.Location = New System.Drawing.Point(402, 9)
        Me.lblironing.Name = "lblironing"
        Me.lblironing.Size = New System.Drawing.Size(103, 33)
        Me.lblironing.TabIndex = 7
        Me.lblironing.Text = "Ironing"
        '
        'lbllights
        '
        Me.lbllights.AutoSize = True
        Me.lbllights.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllights.ForeColor = System.Drawing.Color.Purple
        Me.lbllights.Location = New System.Drawing.Point(721, 9)
        Me.lbllights.Name = "lbllights"
        Me.lbllights.Size = New System.Drawing.Size(87, 33)
        Me.lbllights.TabIndex = 8
        Me.lbllights.Text = "Lights"
        '
        'lblwicks
        '
        Me.lblwicks.AutoSize = True
        Me.lblwicks.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblwicks.ForeColor = System.Drawing.Color.Purple
        Me.lblwicks.Location = New System.Drawing.Point(721, 167)
        Me.lblwicks.Name = "lblwicks"
        Me.lblwicks.Size = New System.Drawing.Size(87, 33)
        Me.lblwicks.TabIndex = 9
        Me.lblwicks.Text = "Wicks"
        '
        'lbldyes
        '
        Me.lbldyes.AutoSize = True
        Me.lbldyes.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldyes.ForeColor = System.Drawing.Color.Purple
        Me.lbldyes.Location = New System.Drawing.Point(410, 330)
        Me.lbldyes.Name = "lbldyes"
        Me.lbldyes.Size = New System.Drawing.Size(78, 33)
        Me.lbldyes.TabIndex = 10
        Me.lbldyes.Text = "Dyes"
        '
        'lblpermanent
        '
        Me.lblpermanent.AutoSize = True
        Me.lblpermanent.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpermanent.ForeColor = System.Drawing.Color.Purple
        Me.lblpermanent.Location = New System.Drawing.Point(698, 330)
        Me.lblpermanent.Name = "lblpermanent"
        Me.lblpermanent.Size = New System.Drawing.Size(161, 33)
        Me.lblpermanent.TabIndex = 11
        Me.lblpermanent.Text = "Permanent"
        '
        'lblpricedried
        '
        Me.lblpricedried.AutoSize = True
        Me.lblpricedried.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricedried.ForeColor = System.Drawing.Color.Red
        Me.lblpricedried.Location = New System.Drawing.Point(400, 210)
        Me.lblpricedried.Name = "lblpricedried"
        Me.lblpricedried.Size = New System.Drawing.Size(83, 44)
        Me.lblpricedried.TabIndex = 12
        Me.lblpricedried.Text = "$80"
        '
        'lblpricewicks
        '
        Me.lblpricewicks.AutoSize = True
        Me.lblpricewicks.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricewicks.ForeColor = System.Drawing.Color.Red
        Me.lblpricewicks.Location = New System.Drawing.Point(719, 210)
        Me.lblpricewicks.Name = "lblpricewicks"
        Me.lblpricewicks.Size = New System.Drawing.Size(104, 44)
        Me.lblpricewicks.TabIndex = 13
        Me.lblpricewicks.Text = "$600"
        '
        'lblpricelights
        '
        Me.lblpricelights.AutoSize = True
        Me.lblpricelights.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricelights.ForeColor = System.Drawing.Color.Red
        Me.lblpricelights.Location = New System.Drawing.Point(719, 51)
        Me.lblpricelights.Name = "lblpricelights"
        Me.lblpricelights.Size = New System.Drawing.Size(104, 44)
        Me.lblpricelights.TabIndex = 14
        Me.lblpricelights.Text = "$500"
        '
        'lblpricepermanent
        '
        Me.lblpricepermanent.AutoSize = True
        Me.lblpricepermanent.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricepermanent.ForeColor = System.Drawing.Color.Red
        Me.lblpricepermanent.Location = New System.Drawing.Point(719, 378)
        Me.lblpricepermanent.Name = "lblpricepermanent"
        Me.lblpricepermanent.Size = New System.Drawing.Size(104, 44)
        Me.lblpricepermanent.TabIndex = 15
        Me.lblpricepermanent.Text = "$400"
        '
        'lblpricedyes
        '
        Me.lblpricedyes.AutoSize = True
        Me.lblpricedyes.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricedyes.ForeColor = System.Drawing.Color.Red
        Me.lblpricedyes.Location = New System.Drawing.Point(401, 378)
        Me.lblpricedyes.Name = "lblpricedyes"
        Me.lblpricedyes.Size = New System.Drawing.Size(104, 44)
        Me.lblpricedyes.TabIndex = 16
        Me.lblpricedyes.Text = "$400"
        '
        'lblpriceironing
        '
        Me.lblpriceironing.AutoSize = True
        Me.lblpriceironing.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceironing.ForeColor = System.Drawing.Color.Red
        Me.lblpriceironing.Location = New System.Drawing.Point(400, 51)
        Me.lblpriceironing.Name = "lblpriceironing"
        Me.lblpriceironing.Size = New System.Drawing.Size(83, 44)
        Me.lblpriceironing.TabIndex = 17
        Me.lblpriceironing.Text = "$80"
        '
        'lblpricehairstyle
        '
        Me.lblpricehairstyle.AutoSize = True
        Me.lblpricehairstyle.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricehairstyle.ForeColor = System.Drawing.Color.Red
        Me.lblpricehairstyle.Location = New System.Drawing.Point(94, 378)
        Me.lblpricehairstyle.Name = "lblpricehairstyle"
        Me.lblpricehairstyle.Size = New System.Drawing.Size(104, 44)
        Me.lblpricehairstyle.TabIndex = 18
        Me.lblpricehairstyle.Text = "$180"
        '
        'nudlady
        '
        Me.nudlady.Location = New System.Drawing.Point(69, 257)
        Me.nudlady.Name = "nudlady"
        Me.nudlady.Size = New System.Drawing.Size(139, 20)
        Me.nudlady.TabIndex = 19
        '
        'nuddried
        '
        Me.nuddried.Location = New System.Drawing.Point(383, 257)
        Me.nuddried.Name = "nuddried"
        Me.nuddried.Size = New System.Drawing.Size(139, 20)
        Me.nuddried.TabIndex = 20
        '
        'nuddyes
        '
        Me.nuddyes.Location = New System.Drawing.Point(383, 425)
        Me.nuddyes.Name = "nuddyes"
        Me.nuddyes.Size = New System.Drawing.Size(139, 20)
        Me.nuddyes.TabIndex = 22
        '
        'nudpermanent
        '
        Me.nudpermanent.Location = New System.Drawing.Point(704, 425)
        Me.nudpermanent.Name = "nudpermanent"
        Me.nudpermanent.Size = New System.Drawing.Size(139, 20)
        Me.nudpermanent.TabIndex = 23
        '
        'nudwicks
        '
        Me.nudwicks.Location = New System.Drawing.Point(704, 257)
        Me.nudwicks.Name = "nudwicks"
        Me.nudwicks.Size = New System.Drawing.Size(139, 20)
        Me.nudwicks.TabIndex = 24
        '
        'nudlights
        '
        Me.nudlights.Location = New System.Drawing.Point(704, 98)
        Me.nudlights.Name = "nudlights"
        Me.nudlights.Size = New System.Drawing.Size(139, 20)
        Me.nudlights.TabIndex = 25
        '
        'nudironing
        '
        Me.nudironing.Location = New System.Drawing.Point(383, 98)
        Me.nudironing.Name = "nudironing"
        Me.nudironing.Size = New System.Drawing.Size(139, 20)
        Me.nudironing.TabIndex = 26
        '
        'nudhairstyle
        '
        Me.nudhairstyle.Location = New System.Drawing.Point(69, 425)
        Me.nudhairstyle.Name = "nudhairstyle"
        Me.nudhairstyle.Size = New System.Drawing.Size(139, 20)
        Me.nudhairstyle.TabIndex = 27
        '
        'btnhome
        '
        Me.btnhome.Font = New System.Drawing.Font("KG Change This Heart", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhome.ForeColor = System.Drawing.Color.Purple
        Me.btnhome.Location = New System.Drawing.Point(746, 474)
        Me.btnhome.Name = "btnhome"
        Me.btnhome.Size = New System.Drawing.Size(140, 31)
        Me.btnhome.TabIndex = 28
        Me.btnhome.Text = "HOME"
        Me.btnhome.UseVisualStyleBackColor = True
        '
        'hair_services
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(888, 506)
        Me.Controls.Add(Me.btnhome)
        Me.Controls.Add(Me.nudhairstyle)
        Me.Controls.Add(Me.nudironing)
        Me.Controls.Add(Me.nudlights)
        Me.Controls.Add(Me.nudwicks)
        Me.Controls.Add(Me.nudpermanent)
        Me.Controls.Add(Me.nuddyes)
        Me.Controls.Add(Me.nuddried)
        Me.Controls.Add(Me.nudlady)
        Me.Controls.Add(Me.lblpricehairstyle)
        Me.Controls.Add(Me.lblpriceironing)
        Me.Controls.Add(Me.lblpricedyes)
        Me.Controls.Add(Me.lblpricepermanent)
        Me.Controls.Add(Me.lblpricelights)
        Me.Controls.Add(Me.lblpricewicks)
        Me.Controls.Add(Me.lblpricedried)
        Me.Controls.Add(Me.lblpermanent)
        Me.Controls.Add(Me.lbldyes)
        Me.Controls.Add(Me.lblwicks)
        Me.Controls.Add(Me.lbllights)
        Me.Controls.Add(Me.lblironing)
        Me.Controls.Add(Me.lbldried)
        Me.Controls.Add(Me.lblhairstyle)
        Me.Controls.Add(Me.nudgentleman)
        Me.Controls.Add(Me.lblpricelady)
        Me.Controls.Add(Me.lblpricegentleman)
        Me.Controls.Add(Me.lbllady)
        Me.Controls.Add(Me.lblgentleman)
        Me.Name = "hair_services"
        Me.Text = "hair_services"
        CType(Me.nudgentleman, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudlady, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nuddried, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nuddyes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudpermanent, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudwicks, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudlights, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudironing, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudhairstyle, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblgentleman As System.Windows.Forms.Label
    Friend WithEvents lbllady As System.Windows.Forms.Label
    Friend WithEvents lblpricegentleman As System.Windows.Forms.Label
    Friend WithEvents lblpricelady As System.Windows.Forms.Label
    Friend WithEvents nudgentleman As System.Windows.Forms.NumericUpDown
    Friend WithEvents lblhairstyle As System.Windows.Forms.Label
    Friend WithEvents lbldried As System.Windows.Forms.Label
    Friend WithEvents lblironing As System.Windows.Forms.Label
    Friend WithEvents lbllights As System.Windows.Forms.Label
    Friend WithEvents lblwicks As System.Windows.Forms.Label
    Friend WithEvents lbldyes As System.Windows.Forms.Label
    Friend WithEvents lblpermanent As System.Windows.Forms.Label
    Friend WithEvents lblpricedried As System.Windows.Forms.Label
    Friend WithEvents lblpricewicks As System.Windows.Forms.Label
    Friend WithEvents lblpricelights As System.Windows.Forms.Label
    Friend WithEvents lblpricepermanent As System.Windows.Forms.Label
    Friend WithEvents lblpricedyes As System.Windows.Forms.Label
    Friend WithEvents lblpriceironing As System.Windows.Forms.Label
    Friend WithEvents lblpricehairstyle As System.Windows.Forms.Label
    Friend WithEvents nudlady As System.Windows.Forms.NumericUpDown
    Friend WithEvents nuddried As System.Windows.Forms.NumericUpDown
    Friend WithEvents nuddyes As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudpermanent As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudwicks As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudlights As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudironing As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudhairstyle As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnhome As System.Windows.Forms.Button
End Class
