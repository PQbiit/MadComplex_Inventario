﻿Public Class SPA

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblpricemanicure.Click

    End Sub
End Class