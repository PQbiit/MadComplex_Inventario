﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SPA
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnhome = New System.Windows.Forms.Button
        Me.lblpedicure = New System.Windows.Forms.Label
        Me.lblmanicure = New System.Windows.Forms.Label
        Me.lblnails = New System.Windows.Forms.Label
        Me.lblpricepedicure = New System.Windows.Forms.Label
        Me.lblpricemanicure = New System.Windows.Forms.Label
        Me.lblpricenails = New System.Windows.Forms.Label
        Me.nudnails = New System.Windows.Forms.NumericUpDown
        Me.nudmanicure = New System.Windows.Forms.NumericUpDown
        Me.nudpedicure = New System.Windows.Forms.NumericUpDown
        CType(Me.nudnails, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudmanicure, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudpedicure, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnhome
        '
        Me.btnhome.Font = New System.Drawing.Font("KG Change This Heart", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhome.ForeColor = System.Drawing.Color.Purple
        Me.btnhome.Location = New System.Drawing.Point(747, 472)
        Me.btnhome.Name = "btnhome"
        Me.btnhome.Size = New System.Drawing.Size(140, 31)
        Me.btnhome.TabIndex = 29
        Me.btnhome.Text = "HOME"
        Me.btnhome.UseVisualStyleBackColor = True
        '
        'lblpedicure
        '
        Me.lblpedicure.AutoSize = True
        Me.lblpedicure.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpedicure.ForeColor = System.Drawing.Color.Purple
        Me.lblpedicure.Location = New System.Drawing.Point(674, 125)
        Me.lblpedicure.Name = "lblpedicure"
        Me.lblpedicure.Size = New System.Drawing.Size(133, 33)
        Me.lblpedicure.TabIndex = 30
        Me.lblpedicure.Text = "Pedicure"
        '
        'lblmanicure
        '
        Me.lblmanicure.AutoSize = True
        Me.lblmanicure.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmanicure.ForeColor = System.Drawing.Color.Purple
        Me.lblmanicure.Location = New System.Drawing.Point(352, 125)
        Me.lblmanicure.Name = "lblmanicure"
        Me.lblmanicure.Size = New System.Drawing.Size(139, 33)
        Me.lblmanicure.TabIndex = 31
        Me.lblmanicure.Text = "Manicure"
        '
        'lblnails
        '
        Me.lblnails.AutoSize = True
        Me.lblnails.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblnails.ForeColor = System.Drawing.Color.Purple
        Me.lblnails.Location = New System.Drawing.Point(62, 125)
        Me.lblnails.Name = "lblnails"
        Me.lblnails.Size = New System.Drawing.Size(75, 33)
        Me.lblnails.TabIndex = 32
        Me.lblnails.Text = "Nails"
        '
        'lblpricepedicure
        '
        Me.lblpricepedicure.AutoSize = True
        Me.lblpricepedicure.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricepedicure.ForeColor = System.Drawing.Color.Red
        Me.lblpricepedicure.Location = New System.Drawing.Point(686, 174)
        Me.lblpricepedicure.Name = "lblpricepedicure"
        Me.lblpricepedicure.Size = New System.Drawing.Size(104, 44)
        Me.lblpricepedicure.TabIndex = 33
        Me.lblpricepedicure.Text = "$150"
        '
        'lblpricemanicure
        '
        Me.lblpricemanicure.AutoSize = True
        Me.lblpricemanicure.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricemanicure.ForeColor = System.Drawing.Color.Red
        Me.lblpricemanicure.Location = New System.Drawing.Point(364, 174)
        Me.lblpricemanicure.Name = "lblpricemanicure"
        Me.lblpricemanicure.Size = New System.Drawing.Size(104, 44)
        Me.lblpricemanicure.TabIndex = 34
        Me.lblpricemanicure.Text = "$100"
        '
        'lblpricenails
        '
        Me.lblpricenails.AutoSize = True
        Me.lblpricenails.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricenails.ForeColor = System.Drawing.Color.Red
        Me.lblpricenails.Location = New System.Drawing.Point(44, 174)
        Me.lblpricenails.Name = "lblpricenails"
        Me.lblpricenails.Size = New System.Drawing.Size(104, 44)
        Me.lblpricenails.TabIndex = 35
        Me.lblpricenails.Text = "$200"
        '
        'nudnails
        '
        Me.nudnails.Location = New System.Drawing.Point(42, 238)
        Me.nudnails.Name = "nudnails"
        Me.nudnails.Size = New System.Drawing.Size(120, 20)
        Me.nudnails.TabIndex = 36
        '
        'nudmanicure
        '
        Me.nudmanicure.Location = New System.Drawing.Point(358, 238)
        Me.nudmanicure.Name = "nudmanicure"
        Me.nudmanicure.Size = New System.Drawing.Size(120, 20)
        Me.nudmanicure.TabIndex = 37
        '
        'nudpedicure
        '
        Me.nudpedicure.Location = New System.Drawing.Point(687, 238)
        Me.nudpedicure.Name = "nudpedicure"
        Me.nudpedicure.Size = New System.Drawing.Size(120, 20)
        Me.nudpedicure.TabIndex = 38
        '
        'SPA
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(888, 505)
        Me.Controls.Add(Me.nudpedicure)
        Me.Controls.Add(Me.nudmanicure)
        Me.Controls.Add(Me.nudnails)
        Me.Controls.Add(Me.lblpricenails)
        Me.Controls.Add(Me.lblpricemanicure)
        Me.Controls.Add(Me.lblpricepedicure)
        Me.Controls.Add(Me.lblnails)
        Me.Controls.Add(Me.lblmanicure)
        Me.Controls.Add(Me.lblpedicure)
        Me.Controls.Add(Me.btnhome)
        Me.Name = "SPA"
        Me.Text = "SPA"
        CType(Me.nudnails, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudmanicure, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudpedicure, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnhome As System.Windows.Forms.Button
    Friend WithEvents lblpedicure As System.Windows.Forms.Label
    Friend WithEvents lblmanicure As System.Windows.Forms.Label
    Friend WithEvents lblnails As System.Windows.Forms.Label
    Friend WithEvents lblpricepedicure As System.Windows.Forms.Label
    Friend WithEvents lblpricemanicure As System.Windows.Forms.Label
    Friend WithEvents lblpricenails As System.Windows.Forms.Label
    Friend WithEvents nudnails As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudmanicure As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudpedicure As System.Windows.Forms.NumericUpDown
End Class
