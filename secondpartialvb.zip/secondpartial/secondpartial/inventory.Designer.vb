﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class inventory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnhome = New System.Windows.Forms.Button
        Me.lblgodwell = New System.Windows.Forms.Label
        Me.lblbyfama = New System.Windows.Forms.Label
        Me.lblpostquan = New System.Windows.Forms.Label
        Me.lbllabonte = New System.Windows.Forms.Label
        Me.lblrevlon = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'btnhome
        '
        Me.btnhome.Font = New System.Drawing.Font("KG Change This Heart", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhome.ForeColor = System.Drawing.Color.Purple
        Me.btnhome.Location = New System.Drawing.Point(730, 463)
        Me.btnhome.Name = "btnhome"
        Me.btnhome.Size = New System.Drawing.Size(140, 31)
        Me.btnhome.TabIndex = 31
        Me.btnhome.Text = "HOME"
        Me.btnhome.UseVisualStyleBackColor = True
        '
        'lblgodwell
        '
        Me.lblgodwell.AutoSize = True
        Me.lblgodwell.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgodwell.ForeColor = System.Drawing.Color.Purple
        Me.lblgodwell.Location = New System.Drawing.Point(12, 20)
        Me.lblgodwell.Name = "lblgodwell"
        Me.lblgodwell.Size = New System.Drawing.Size(130, 33)
        Me.lblgodwell.TabIndex = 44
        Me.lblgodwell.Text = "Godwell"
        '
        'lblbyfama
        '
        Me.lblbyfama.AutoSize = True
        Me.lblbyfama.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbyfama.ForeColor = System.Drawing.Color.Purple
        Me.lblbyfama.Location = New System.Drawing.Point(300, 256)
        Me.lblbyfama.Name = "lblbyfama"
        Me.lblbyfama.Size = New System.Drawing.Size(123, 33)
        Me.lblbyfama.TabIndex = 46
        Me.lblbyfama.Text = "By fama"
        '
        'lblpostquan
        '
        Me.lblpostquan.AutoSize = True
        Me.lblpostquan.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpostquan.ForeColor = System.Drawing.Color.Purple
        Me.lblpostquan.Location = New System.Drawing.Point(12, 256)
        Me.lblpostquan.Name = "lblpostquan"
        Me.lblpostquan.Size = New System.Drawing.Size(137, 33)
        Me.lblpostquan.TabIndex = 47
        Me.lblpostquan.Text = "Postquan"
        '
        'lbllabonte
        '
        Me.lbllabonte.AutoSize = True
        Me.lbllabonte.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllabonte.ForeColor = System.Drawing.Color.Purple
        Me.lbllabonte.Location = New System.Drawing.Point(598, 20)
        Me.lbllabonte.Name = "lbllabonte"
        Me.lbllabonte.Size = New System.Drawing.Size(125, 33)
        Me.lbllabonte.TabIndex = 48
        Me.lbllabonte.Text = "Labonte"
        '
        'lblrevlon
        '
        Me.lblrevlon.AutoSize = True
        Me.lblrevlon.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblrevlon.ForeColor = System.Drawing.Color.Purple
        Me.lblrevlon.Location = New System.Drawing.Point(300, 20)
        Me.lblrevlon.Name = "lblrevlon"
        Me.lblrevlon.Size = New System.Drawing.Size(106, 33)
        Me.lblrevlon.TabIndex = 49
        Me.lblrevlon.Text = "Revlon"
        '
        'inventory
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(882, 506)
        Me.Controls.Add(Me.lblrevlon)
        Me.Controls.Add(Me.lbllabonte)
        Me.Controls.Add(Me.lblpostquan)
        Me.Controls.Add(Me.lblbyfama)
        Me.Controls.Add(Me.lblgodwell)
        Me.Controls.Add(Me.btnhome)
        Me.Name = "inventory"
        Me.Text = "inventory"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnhome As System.Windows.Forms.Button
    Friend WithEvents lblgodwell As System.Windows.Forms.Label
    Friend WithEvents lblbyfama As System.Windows.Forms.Label
    Friend WithEvents lblpostquan As System.Windows.Forms.Label
    Friend WithEvents lbllabonte As System.Windows.Forms.Label
    Friend WithEvents lblrevlon As System.Windows.Forms.Label
End Class
