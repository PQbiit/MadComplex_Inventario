﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class accounting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnhome = New System.Windows.Forms.Button
        Me.lbloutcome = New System.Windows.Forms.Label
        Me.lblincome = New System.Windows.Forms.Label
        Me.lblmonthin = New System.Windows.Forms.Label
        Me.lblmonthout = New System.Windows.Forms.Label
        Me.lblweekout = New System.Windows.Forms.Label
        Me.lbldayout = New System.Windows.Forms.Label
        Me.lbldayin = New System.Windows.Forms.Label
        Me.lblweekin = New System.Windows.Forms.Label
        Me.lblyearin = New System.Windows.Forms.Label
        Me.lblyearout = New System.Windows.Forms.Label
        Me.txtboxdayin = New System.Windows.Forms.TextBox
        Me.txtboxdayout = New System.Windows.Forms.TextBox
        Me.txtboxyearin = New System.Windows.Forms.TextBox
        Me.txtboxmonthin = New System.Windows.Forms.TextBox
        Me.txtboxweekin = New System.Windows.Forms.TextBox
        Me.txtboxyearout = New System.Windows.Forms.TextBox
        Me.txtboxmonthout = New System.Windows.Forms.TextBox
        Me.txtboxweekout = New System.Windows.Forms.TextBox
        Me.lblresultin = New System.Windows.Forms.Label
        Me.lblresultout = New System.Windows.Forms.Label
        Me.lblpriceresultin = New System.Windows.Forms.Label
        Me.lblpriceresultout = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'btnhome
        '
        Me.btnhome.Font = New System.Drawing.Font("KG Change This Heart", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhome.ForeColor = System.Drawing.Color.Purple
        Me.btnhome.Location = New System.Drawing.Point(729, 458)
        Me.btnhome.Name = "btnhome"
        Me.btnhome.Size = New System.Drawing.Size(140, 31)
        Me.btnhome.TabIndex = 31
        Me.btnhome.Text = "HOME"
        Me.btnhome.UseVisualStyleBackColor = True
        '
        'lbloutcome
        '
        Me.lbloutcome.AutoSize = True
        Me.lbloutcome.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbloutcome.ForeColor = System.Drawing.Color.Purple
        Me.lbloutcome.Location = New System.Drawing.Point(540, 25)
        Me.lbloutcome.Name = "lbloutcome"
        Me.lbloutcome.Size = New System.Drawing.Size(143, 33)
        Me.lbloutcome.TabIndex = 32
        Me.lbloutcome.Text = "Outcome"
        '
        'lblincome
        '
        Me.lblincome.AutoSize = True
        Me.lblincome.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblincome.ForeColor = System.Drawing.Color.Purple
        Me.lblincome.Location = New System.Drawing.Point(147, 25)
        Me.lblincome.Name = "lblincome"
        Me.lblincome.Size = New System.Drawing.Size(116, 33)
        Me.lblincome.TabIndex = 33
        Me.lblincome.Text = "Income"
        '
        'lblmonthin
        '
        Me.lblmonthin.AutoSize = True
        Me.lblmonthin.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmonthin.ForeColor = System.Drawing.Color.Purple
        Me.lblmonthin.Location = New System.Drawing.Point(75, 238)
        Me.lblmonthin.Name = "lblmonthin"
        Me.lblmonthin.Size = New System.Drawing.Size(76, 24)
        Me.lblmonthin.TabIndex = 34
        Me.lblmonthin.Text = "Month"
        '
        'lblmonthout
        '
        Me.lblmonthout.AutoSize = True
        Me.lblmonthout.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmonthout.ForeColor = System.Drawing.Color.Purple
        Me.lblmonthout.Location = New System.Drawing.Point(450, 238)
        Me.lblmonthout.Name = "lblmonthout"
        Me.lblmonthout.Size = New System.Drawing.Size(76, 24)
        Me.lblmonthout.TabIndex = 35
        Me.lblmonthout.Text = "Month"
        '
        'lblweekout
        '
        Me.lblweekout.AutoSize = True
        Me.lblweekout.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblweekout.ForeColor = System.Drawing.Color.Purple
        Me.lblweekout.Location = New System.Drawing.Point(450, 159)
        Me.lblweekout.Name = "lblweekout"
        Me.lblweekout.Size = New System.Drawing.Size(68, 24)
        Me.lblweekout.TabIndex = 36
        Me.lblweekout.Text = "Week"
        '
        'lbldayout
        '
        Me.lbldayout.AutoSize = True
        Me.lbldayout.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldayout.ForeColor = System.Drawing.Color.Purple
        Me.lbldayout.Location = New System.Drawing.Point(450, 79)
        Me.lbldayout.Name = "lbldayout"
        Me.lbldayout.Size = New System.Drawing.Size(51, 24)
        Me.lbldayout.TabIndex = 37
        Me.lbldayout.Text = "Day"
        '
        'lbldayin
        '
        Me.lbldayin.AutoSize = True
        Me.lbldayin.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldayin.ForeColor = System.Drawing.Color.Purple
        Me.lbldayin.Location = New System.Drawing.Point(75, 79)
        Me.lbldayin.Name = "lbldayin"
        Me.lbldayin.Size = New System.Drawing.Size(51, 24)
        Me.lbldayin.TabIndex = 38
        Me.lbldayin.Text = "Day"
        '
        'lblweekin
        '
        Me.lblweekin.AutoSize = True
        Me.lblweekin.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblweekin.ForeColor = System.Drawing.Color.Purple
        Me.lblweekin.Location = New System.Drawing.Point(75, 159)
        Me.lblweekin.Name = "lblweekin"
        Me.lblweekin.Size = New System.Drawing.Size(68, 24)
        Me.lblweekin.TabIndex = 39
        Me.lblweekin.Text = "Week"
        '
        'lblyearin
        '
        Me.lblyearin.AutoSize = True
        Me.lblyearin.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblyearin.ForeColor = System.Drawing.Color.Purple
        Me.lblyearin.Location = New System.Drawing.Point(75, 303)
        Me.lblyearin.Name = "lblyearin"
        Me.lblyearin.Size = New System.Drawing.Size(57, 24)
        Me.lblyearin.TabIndex = 40
        Me.lblyearin.Text = "Year"
        '
        'lblyearout
        '
        Me.lblyearout.AutoSize = True
        Me.lblyearout.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblyearout.ForeColor = System.Drawing.Color.Purple
        Me.lblyearout.Location = New System.Drawing.Point(450, 303)
        Me.lblyearout.Name = "lblyearout"
        Me.lblyearout.Size = New System.Drawing.Size(57, 24)
        Me.lblyearout.TabIndex = 41
        Me.lblyearout.Text = "Year"
        '
        'txtboxdayin
        '
        Me.txtboxdayin.Location = New System.Drawing.Point(166, 83)
        Me.txtboxdayin.Name = "txtboxdayin"
        Me.txtboxdayin.Size = New System.Drawing.Size(108, 20)
        Me.txtboxdayin.TabIndex = 42
        '
        'txtboxdayout
        '
        Me.txtboxdayout.Location = New System.Drawing.Point(575, 85)
        Me.txtboxdayout.Name = "txtboxdayout"
        Me.txtboxdayout.Size = New System.Drawing.Size(108, 20)
        Me.txtboxdayout.TabIndex = 43
        '
        'txtboxyearin
        '
        Me.txtboxyearin.Location = New System.Drawing.Point(166, 307)
        Me.txtboxyearin.Name = "txtboxyearin"
        Me.txtboxyearin.Size = New System.Drawing.Size(108, 20)
        Me.txtboxyearin.TabIndex = 44
        '
        'txtboxmonthin
        '
        Me.txtboxmonthin.Location = New System.Drawing.Point(166, 242)
        Me.txtboxmonthin.Name = "txtboxmonthin"
        Me.txtboxmonthin.Size = New System.Drawing.Size(108, 20)
        Me.txtboxmonthin.TabIndex = 45
        '
        'txtboxweekin
        '
        Me.txtboxweekin.Location = New System.Drawing.Point(166, 163)
        Me.txtboxweekin.Name = "txtboxweekin"
        Me.txtboxweekin.Size = New System.Drawing.Size(108, 20)
        Me.txtboxweekin.TabIndex = 46
        '
        'txtboxyearout
        '
        Me.txtboxyearout.Location = New System.Drawing.Point(575, 309)
        Me.txtboxyearout.Name = "txtboxyearout"
        Me.txtboxyearout.Size = New System.Drawing.Size(108, 20)
        Me.txtboxyearout.TabIndex = 47
        '
        'txtboxmonthout
        '
        Me.txtboxmonthout.Location = New System.Drawing.Point(575, 242)
        Me.txtboxmonthout.Name = "txtboxmonthout"
        Me.txtboxmonthout.Size = New System.Drawing.Size(108, 20)
        Me.txtboxmonthout.TabIndex = 48
        '
        'txtboxweekout
        '
        Me.txtboxweekout.Location = New System.Drawing.Point(575, 165)
        Me.txtboxweekout.Name = "txtboxweekout"
        Me.txtboxweekout.Size = New System.Drawing.Size(108, 20)
        Me.txtboxweekout.TabIndex = 49
        '
        'lblresultin
        '
        Me.lblresultin.AutoSize = True
        Me.lblresultin.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblresultin.ForeColor = System.Drawing.Color.Purple
        Me.lblresultin.Location = New System.Drawing.Point(147, 385)
        Me.lblresultin.Name = "lblresultin"
        Me.lblresultin.Size = New System.Drawing.Size(105, 33)
        Me.lblresultin.TabIndex = 50
        Me.lblresultin.Text = "Result: "
        '
        'lblresultout
        '
        Me.lblresultout.AutoSize = True
        Me.lblresultout.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblresultout.ForeColor = System.Drawing.Color.Purple
        Me.lblresultout.Location = New System.Drawing.Point(540, 385)
        Me.lblresultout.Name = "lblresultout"
        Me.lblresultout.Size = New System.Drawing.Size(105, 33)
        Me.lblresultout.TabIndex = 51
        Me.lblresultout.Text = "Result: "
        '
        'lblpriceresultin
        '
        Me.lblpriceresultin.AutoSize = True
        Me.lblpriceresultin.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceresultin.ForeColor = System.Drawing.Color.Red
        Me.lblpriceresultin.Location = New System.Drawing.Point(265, 374)
        Me.lblpriceresultin.Name = "lblpriceresultin"
        Me.lblpriceresultin.Size = New System.Drawing.Size(0, 44)
        Me.lblpriceresultin.TabIndex = 52
        '
        'lblpriceresultout
        '
        Me.lblpriceresultout.AutoSize = True
        Me.lblpriceresultout.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceresultout.ForeColor = System.Drawing.Color.Red
        Me.lblpriceresultout.Location = New System.Drawing.Point(660, 374)
        Me.lblpriceresultout.Name = "lblpriceresultout"
        Me.lblpriceresultout.Size = New System.Drawing.Size(0, 44)
        Me.lblpriceresultout.TabIndex = 53
        '
        'accounting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(881, 501)
        Me.Controls.Add(Me.lblpriceresultout)
        Me.Controls.Add(Me.lblpriceresultin)
        Me.Controls.Add(Me.lblresultout)
        Me.Controls.Add(Me.lblresultin)
        Me.Controls.Add(Me.txtboxweekout)
        Me.Controls.Add(Me.txtboxmonthout)
        Me.Controls.Add(Me.txtboxyearout)
        Me.Controls.Add(Me.txtboxweekin)
        Me.Controls.Add(Me.txtboxmonthin)
        Me.Controls.Add(Me.txtboxyearin)
        Me.Controls.Add(Me.txtboxdayout)
        Me.Controls.Add(Me.txtboxdayin)
        Me.Controls.Add(Me.lblyearout)
        Me.Controls.Add(Me.lblyearin)
        Me.Controls.Add(Me.lblweekin)
        Me.Controls.Add(Me.lbldayin)
        Me.Controls.Add(Me.lbldayout)
        Me.Controls.Add(Me.lblweekout)
        Me.Controls.Add(Me.lblmonthout)
        Me.Controls.Add(Me.lblmonthin)
        Me.Controls.Add(Me.lblincome)
        Me.Controls.Add(Me.lbloutcome)
        Me.Controls.Add(Me.btnhome)
        Me.Name = "accounting"
        Me.Text = "accounting"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnhome As System.Windows.Forms.Button
    Friend WithEvents lbloutcome As System.Windows.Forms.Label
    Friend WithEvents lblincome As System.Windows.Forms.Label
    Friend WithEvents lblmonthin As System.Windows.Forms.Label
    Friend WithEvents lblmonthout As System.Windows.Forms.Label
    Friend WithEvents lblweekout As System.Windows.Forms.Label
    Friend WithEvents lbldayout As System.Windows.Forms.Label
    Friend WithEvents lbldayin As System.Windows.Forms.Label
    Friend WithEvents lblweekin As System.Windows.Forms.Label
    Friend WithEvents lblyearin As System.Windows.Forms.Label
    Friend WithEvents lblyearout As System.Windows.Forms.Label
    Friend WithEvents txtboxdayin As System.Windows.Forms.TextBox
    Friend WithEvents txtboxdayout As System.Windows.Forms.TextBox
    Friend WithEvents txtboxyearin As System.Windows.Forms.TextBox
    Friend WithEvents txtboxmonthin As System.Windows.Forms.TextBox
    Friend WithEvents txtboxweekin As System.Windows.Forms.TextBox
    Friend WithEvents txtboxyearout As System.Windows.Forms.TextBox
    Friend WithEvents txtboxmonthout As System.Windows.Forms.TextBox
    Friend WithEvents txtboxweekout As System.Windows.Forms.TextBox
    Friend WithEvents lblresultin As System.Windows.Forms.Label
    Friend WithEvents lblresultout As System.Windows.Forms.Label
    Friend WithEvents lblpriceresultin As System.Windows.Forms.Label
    Friend WithEvents lblpriceresultout As System.Windows.Forms.Label
End Class
