﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Log_In
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtUserN = New System.Windows.Forms.TextBox
        Me.lblUserN = New System.Windows.Forms.Label
        Me.txtPassW = New System.Windows.Forms.TextBox
        Me.lblPassW = New System.Windows.Forms.Label
        Me.btnLog = New System.Windows.Forms.Button
        Me.btnClear = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'txtUserN
        '
        Me.txtUserN.Location = New System.Drawing.Point(131, 85)
        Me.txtUserN.Name = "txtUserN"
        Me.txtUserN.Size = New System.Drawing.Size(145, 20)
        Me.txtUserN.TabIndex = 0
        '
        'lblUserN
        '
        Me.lblUserN.AutoSize = True
        Me.lblUserN.Location = New System.Drawing.Point(173, 69)
        Me.lblUserN.Name = "lblUserN"
        Me.lblUserN.Size = New System.Drawing.Size(60, 13)
        Me.lblUserN.TabIndex = 1
        Me.lblUserN.Text = "User Name"
        '
        'txtPassW
        '
        Me.txtPassW.Location = New System.Drawing.Point(131, 154)
        Me.txtPassW.Name = "txtPassW"
        Me.txtPassW.Size = New System.Drawing.Size(145, 20)
        Me.txtPassW.TabIndex = 2
        '
        'lblPassW
        '
        Me.lblPassW.AutoSize = True
        Me.lblPassW.Location = New System.Drawing.Point(173, 138)
        Me.lblPassW.Name = "lblPassW"
        Me.lblPassW.Size = New System.Drawing.Size(53, 13)
        Me.lblPassW.TabIndex = 3
        Me.lblPassW.Text = "Password"
        '
        'btnLog
        '
        Me.btnLog.Location = New System.Drawing.Point(112, 203)
        Me.btnLog.Name = "btnLog"
        Me.btnLog.Size = New System.Drawing.Size(75, 23)
        Me.btnLog.TabIndex = 4
        Me.btnLog.Text = "Log In"
        Me.btnLog.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(217, 203)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 5
        Me.btnClear.Text = "Clear Id´s"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Log_In
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Highlight
        Me.ClientSize = New System.Drawing.Size(418, 388)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnLog)
        Me.Controls.Add(Me.lblPassW)
        Me.Controls.Add(Me.txtPassW)
        Me.Controls.Add(Me.lblUserN)
        Me.Controls.Add(Me.txtUserN)
        Me.Name = "Log_In"
        Me.Text = "iManage Log In"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtUserN As System.Windows.Forms.TextBox
    Friend WithEvents lblUserN As System.Windows.Forms.Label
    Friend WithEvents txtPassW As System.Windows.Forms.TextBox
    Friend WithEvents lblPassW As System.Windows.Forms.Label
    Friend WithEvents btnLog As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
End Class
