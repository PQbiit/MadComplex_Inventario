﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class inventory
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnhome = New System.Windows.Forms.Button
        Me.lblgodwell = New System.Windows.Forms.Label
        Me.lblbyfama = New System.Windows.Forms.Label
        Me.lblpostquan = New System.Windows.Forms.Label
        Me.lbllabonte = New System.Windows.Forms.Label
        Me.lblrevlon = New System.Windows.Forms.Label
        Me.lbldyestintsgodwell = New System.Windows.Forms.Label
        Me.lblpricedyestints = New System.Windows.Forms.Label
        Me.lblshampoogodwell = New System.Windows.Forms.Label
        Me.lblkerasil = New System.Windows.Forms.Label
        Me.lblpricekerasil = New System.Windows.Forms.Label
        Me.lblpriceshampoo = New System.Windows.Forms.Label
        Me.lbluniqone = New System.Windows.Forms.Label
        Me.lbldyestintsrevlon = New System.Windows.Forms.Label
        Me.lblfacetwo = New System.Windows.Forms.Label
        Me.lblshampoobyfama = New System.Windows.Forms.Label
        Me.lblqodtreatment = New System.Windows.Forms.Label
        Me.lbldyestintspostquan = New System.Windows.Forms.Label
        Me.lblfinish = New System.Windows.Forms.Label
        Me.lblkeratin = New System.Windows.Forms.Label
        Me.lblmatting = New System.Windows.Forms.Label
        Me.lblfeedsext = New System.Windows.Forms.Label
        Me.lblvitamine = New System.Windows.Forms.Label
        Me.lblpriceshampoobyfama = New System.Windows.Forms.Label
        Me.lblpricefinish = New System.Windows.Forms.Label
        Me.lblpricekeratin = New System.Windows.Forms.Label
        Me.lblpricematting = New System.Windows.Forms.Label
        Me.lblpricevitamine = New System.Windows.Forms.Label
        Me.lblpricefeedsext = New System.Windows.Forms.Label
        Me.lblpricefacetwo = New System.Windows.Forms.Label
        Me.lblpriceuniqone = New System.Windows.Forms.Label
        Me.lblpricedyestintsrevlon = New System.Windows.Forms.Label
        Me.lblpricedyestintspostquan = New System.Windows.Forms.Label
        Me.lblpriceqodtreatment = New System.Windows.Forms.Label
        Me.lblseasals = New System.Windows.Forms.Label
        Me.lblhandscrub = New System.Windows.Forms.Label
        Me.lblpriceseasals = New System.Windows.Forms.Label
        Me.lblpricehandscrub = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'btnhome
        '
        Me.btnhome.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhome.ForeColor = System.Drawing.Color.Purple
        Me.btnhome.Location = New System.Drawing.Point(730, 463)
        Me.btnhome.Name = "btnhome"
        Me.btnhome.Size = New System.Drawing.Size(140, 31)
        Me.btnhome.TabIndex = 31
        Me.btnhome.Text = "HOME"
        Me.btnhome.UseVisualStyleBackColor = True
        '
        'lblgodwell
        '
        Me.lblgodwell.AutoSize = True
        Me.lblgodwell.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblgodwell.ForeColor = System.Drawing.Color.Purple
        Me.lblgodwell.Location = New System.Drawing.Point(12, 20)
        Me.lblgodwell.Name = "lblgodwell"
        Me.lblgodwell.Size = New System.Drawing.Size(130, 33)
        Me.lblgodwell.TabIndex = 44
        Me.lblgodwell.Text = "Godwell"
        '
        'lblbyfama
        '
        Me.lblbyfama.AutoSize = True
        Me.lblbyfama.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblbyfama.ForeColor = System.Drawing.Color.Purple
        Me.lblbyfama.Location = New System.Drawing.Point(12, 275)
        Me.lblbyfama.Name = "lblbyfama"
        Me.lblbyfama.Size = New System.Drawing.Size(123, 33)
        Me.lblbyfama.TabIndex = 46
        Me.lblbyfama.Text = "By fama"
        '
        'lblpostquan
        '
        Me.lblpostquan.AutoSize = True
        Me.lblpostquan.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpostquan.ForeColor = System.Drawing.Color.Purple
        Me.lblpostquan.Location = New System.Drawing.Point(361, 275)
        Me.lblpostquan.Name = "lblpostquan"
        Me.lblpostquan.Size = New System.Drawing.Size(137, 33)
        Me.lblpostquan.TabIndex = 47
        Me.lblpostquan.Text = "Postquan"
        '
        'lbllabonte
        '
        Me.lbllabonte.AutoSize = True
        Me.lbllabonte.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbllabonte.ForeColor = System.Drawing.Color.Purple
        Me.lbllabonte.Location = New System.Drawing.Point(598, 20)
        Me.lbllabonte.Name = "lbllabonte"
        Me.lbllabonte.Size = New System.Drawing.Size(125, 33)
        Me.lbllabonte.TabIndex = 48
        Me.lbllabonte.Text = "Labonte"
        '
        'lblrevlon
        '
        Me.lblrevlon.AutoSize = True
        Me.lblrevlon.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblrevlon.ForeColor = System.Drawing.Color.Purple
        Me.lblrevlon.Location = New System.Drawing.Point(361, 20)
        Me.lblrevlon.Name = "lblrevlon"
        Me.lblrevlon.Size = New System.Drawing.Size(106, 33)
        Me.lblrevlon.TabIndex = 49
        Me.lblrevlon.Text = "Revlon"
        '
        'lbldyestintsgodwell
        '
        Me.lbldyestintsgodwell.AutoSize = True
        Me.lbldyestintsgodwell.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldyestintsgodwell.ForeColor = System.Drawing.Color.Purple
        Me.lbldyestintsgodwell.Location = New System.Drawing.Point(12, 79)
        Me.lbldyestintsgodwell.Name = "lbldyestintsgodwell"
        Me.lbldyestintsgodwell.Size = New System.Drawing.Size(103, 24)
        Me.lbldyestintsgodwell.TabIndex = 50
        Me.lbldyestintsgodwell.Text = "Dyes tints"
        '
        'lblpricedyestints
        '
        Me.lblpricedyestints.AutoSize = True
        Me.lblpricedyestints.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricedyestints.ForeColor = System.Drawing.Color.Red
        Me.lblpricedyestints.Location = New System.Drawing.Point(121, 64)
        Me.lblpricedyestints.Name = "lblpricedyestints"
        Me.lblpricedyestints.Size = New System.Drawing.Size(89, 39)
        Me.lblpricedyestints.TabIndex = 51
        Me.lblpricedyestints.Text = "$370"
        '
        'lblshampoogodwell
        '
        Me.lblshampoogodwell.AutoSize = True
        Me.lblshampoogodwell.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshampoogodwell.ForeColor = System.Drawing.Color.Purple
        Me.lblshampoogodwell.Location = New System.Drawing.Point(14, 131)
        Me.lblshampoogodwell.Name = "lblshampoogodwell"
        Me.lblshampoogodwell.Size = New System.Drawing.Size(110, 24)
        Me.lblshampoogodwell.TabIndex = 52
        Me.lblshampoogodwell.Text = "Shampoo"
        '
        'lblkerasil
        '
        Me.lblkerasil.AutoSize = True
        Me.lblkerasil.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblkerasil.ForeColor = System.Drawing.Color.Purple
        Me.lblkerasil.Location = New System.Drawing.Point(12, 181)
        Me.lblkerasil.Name = "lblkerasil"
        Me.lblkerasil.Size = New System.Drawing.Size(72, 24)
        Me.lblkerasil.TabIndex = 53
        Me.lblkerasil.Text = "Kerasil"
        '
        'lblpricekerasil
        '
        Me.lblpricekerasil.AutoSize = True
        Me.lblpricekerasil.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricekerasil.ForeColor = System.Drawing.Color.Red
        Me.lblpricekerasil.Location = New System.Drawing.Point(121, 181)
        Me.lblpricekerasil.Name = "lblpricekerasil"
        Me.lblpricekerasil.Size = New System.Drawing.Size(89, 39)
        Me.lblpricekerasil.TabIndex = 54
        Me.lblpricekerasil.Text = "$120"
        '
        'lblpriceshampoo
        '
        Me.lblpriceshampoo.AutoSize = True
        Me.lblpriceshampoo.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceshampoo.ForeColor = System.Drawing.Color.Red
        Me.lblpriceshampoo.Location = New System.Drawing.Point(121, 116)
        Me.lblpriceshampoo.Name = "lblpriceshampoo"
        Me.lblpriceshampoo.Size = New System.Drawing.Size(89, 39)
        Me.lblpriceshampoo.TabIndex = 55
        Me.lblpriceshampoo.Text = "$100"
        '
        'lbluniqone
        '
        Me.lbluniqone.AutoSize = True
        Me.lbluniqone.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbluniqone.ForeColor = System.Drawing.Color.Purple
        Me.lbluniqone.Location = New System.Drawing.Point(363, 131)
        Me.lbluniqone.Name = "lbluniqone"
        Me.lbluniqone.Size = New System.Drawing.Size(104, 24)
        Me.lbluniqone.TabIndex = 56
        Me.lbluniqone.Text = "Uniq One"
        '
        'lbldyestintsrevlon
        '
        Me.lbldyestintsrevlon.AutoSize = True
        Me.lbldyestintsrevlon.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldyestintsrevlon.ForeColor = System.Drawing.Color.Purple
        Me.lbldyestintsrevlon.Location = New System.Drawing.Point(363, 77)
        Me.lbldyestintsrevlon.Name = "lbldyestintsrevlon"
        Me.lbldyestintsrevlon.Size = New System.Drawing.Size(103, 24)
        Me.lbldyestintsrevlon.TabIndex = 57
        Me.lbldyestintsrevlon.Text = "Dyes tints"
        '
        'lblfacetwo
        '
        Me.lblfacetwo.AutoSize = True
        Me.lblfacetwo.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfacetwo.ForeColor = System.Drawing.Color.Purple
        Me.lblfacetwo.Location = New System.Drawing.Point(363, 181)
        Me.lblfacetwo.Name = "lblfacetwo"
        Me.lblfacetwo.Size = New System.Drawing.Size(108, 24)
        Me.lblfacetwo.TabIndex = 58
        Me.lblfacetwo.Text = "Face Two"
        '
        'lblshampoobyfama
        '
        Me.lblshampoobyfama.AutoSize = True
        Me.lblshampoobyfama.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblshampoobyfama.ForeColor = System.Drawing.Color.Purple
        Me.lblshampoobyfama.Location = New System.Drawing.Point(14, 384)
        Me.lblshampoobyfama.Name = "lblshampoobyfama"
        Me.lblshampoobyfama.Size = New System.Drawing.Size(110, 24)
        Me.lblshampoobyfama.TabIndex = 60
        Me.lblshampoobyfama.Text = "Shampoo"
        '
        'lblqodtreatment
        '
        Me.lblqodtreatment.AutoSize = True
        Me.lblqodtreatment.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblqodtreatment.ForeColor = System.Drawing.Color.Purple
        Me.lblqodtreatment.Location = New System.Drawing.Point(14, 330)
        Me.lblqodtreatment.Name = "lblqodtreatment"
        Me.lblqodtreatment.Size = New System.Drawing.Size(172, 24)
        Me.lblqodtreatment.TabIndex = 61
        Me.lblqodtreatment.Text = "QOD Treatment"
        '
        'lbldyestintspostquan
        '
        Me.lbldyestintspostquan.AutoSize = True
        Me.lbldyestintspostquan.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldyestintspostquan.ForeColor = System.Drawing.Color.Purple
        Me.lbldyestintspostquan.Location = New System.Drawing.Point(361, 330)
        Me.lbldyestintspostquan.Name = "lbldyestintspostquan"
        Me.lbldyestintspostquan.Size = New System.Drawing.Size(103, 24)
        Me.lbldyestintspostquan.TabIndex = 62
        Me.lbldyestintspostquan.Text = "Dyes tints"
        '
        'lblfinish
        '
        Me.lblfinish.AutoSize = True
        Me.lblfinish.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfinish.ForeColor = System.Drawing.Color.Purple
        Me.lblfinish.Location = New System.Drawing.Point(600, 254)
        Me.lblfinish.Name = "lblfinish"
        Me.lblfinish.Size = New System.Drawing.Size(60, 24)
        Me.lblfinish.TabIndex = 63
        Me.lblfinish.Text = "Finish"
        '
        'lblkeratin
        '
        Me.lblkeratin.AutoSize = True
        Me.lblkeratin.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblkeratin.ForeColor = System.Drawing.Color.Purple
        Me.lblkeratin.Location = New System.Drawing.Point(600, 209)
        Me.lblkeratin.Name = "lblkeratin"
        Me.lblkeratin.Size = New System.Drawing.Size(79, 24)
        Me.lblkeratin.TabIndex = 64
        Me.lblkeratin.Text = "Keratin"
        '
        'lblmatting
        '
        Me.lblmatting.AutoSize = True
        Me.lblmatting.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmatting.ForeColor = System.Drawing.Color.Purple
        Me.lblmatting.Location = New System.Drawing.Point(600, 162)
        Me.lblmatting.Name = "lblmatting"
        Me.lblmatting.Size = New System.Drawing.Size(87, 24)
        Me.lblmatting.TabIndex = 65
        Me.lblmatting.Text = "Matting"
        '
        'lblfeedsext
        '
        Me.lblfeedsext.AutoSize = True
        Me.lblfeedsext.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblfeedsext.ForeColor = System.Drawing.Color.Purple
        Me.lblfeedsext.Location = New System.Drawing.Point(600, 116)
        Me.lblfeedsext.Name = "lblfeedsext"
        Me.lblfeedsext.Size = New System.Drawing.Size(177, 24)
        Me.lblfeedsext.TabIndex = 66
        Me.lblfeedsext.Text = "Feeds Extensions"
        '
        'lblvitamine
        '
        Me.lblvitamine.AutoSize = True
        Me.lblvitamine.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblvitamine.ForeColor = System.Drawing.Color.Purple
        Me.lblvitamine.Location = New System.Drawing.Point(600, 69)
        Me.lblvitamine.Name = "lblvitamine"
        Me.lblvitamine.Size = New System.Drawing.Size(103, 24)
        Me.lblvitamine.TabIndex = 67
        Me.lblvitamine.Text = "Vitamin E"
        '
        'lblpriceshampoobyfama
        '
        Me.lblpriceshampoobyfama.AutoSize = True
        Me.lblpriceshampoobyfama.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceshampoobyfama.ForeColor = System.Drawing.Color.Red
        Me.lblpriceshampoobyfama.Location = New System.Drawing.Point(201, 371)
        Me.lblpriceshampoobyfama.Name = "lblpriceshampoobyfama"
        Me.lblpriceshampoobyfama.Size = New System.Drawing.Size(89, 39)
        Me.lblpriceshampoobyfama.TabIndex = 68
        Me.lblpriceshampoobyfama.Text = "$100"
        '
        'lblpricefinish
        '
        Me.lblpricefinish.AutoSize = True
        Me.lblpricefinish.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricefinish.ForeColor = System.Drawing.Color.Red
        Me.lblpricefinish.Location = New System.Drawing.Point(781, 241)
        Me.lblpricefinish.Name = "lblpricefinish"
        Me.lblpricefinish.Size = New System.Drawing.Size(71, 39)
        Me.lblpricefinish.TabIndex = 69
        Me.lblpricefinish.Text = "$85"
        '
        'lblpricekeratin
        '
        Me.lblpricekeratin.AutoSize = True
        Me.lblpricekeratin.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricekeratin.ForeColor = System.Drawing.Color.Red
        Me.lblpricekeratin.Location = New System.Drawing.Point(781, 196)
        Me.lblpricekeratin.Name = "lblpricekeratin"
        Me.lblpricekeratin.Size = New System.Drawing.Size(71, 39)
        Me.lblpricekeratin.TabIndex = 70
        Me.lblpricekeratin.Text = "$75"
        '
        'lblpricematting
        '
        Me.lblpricematting.AutoSize = True
        Me.lblpricematting.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricematting.ForeColor = System.Drawing.Color.Red
        Me.lblpricematting.Location = New System.Drawing.Point(781, 149)
        Me.lblpricematting.Name = "lblpricematting"
        Me.lblpricematting.Size = New System.Drawing.Size(71, 39)
        Me.lblpricematting.TabIndex = 71
        Me.lblpricematting.Text = "$75"
        '
        'lblpricevitamine
        '
        Me.lblpricevitamine.AutoSize = True
        Me.lblpricevitamine.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricevitamine.ForeColor = System.Drawing.Color.Red
        Me.lblpricevitamine.Location = New System.Drawing.Point(781, 56)
        Me.lblpricevitamine.Name = "lblpricevitamine"
        Me.lblpricevitamine.Size = New System.Drawing.Size(71, 39)
        Me.lblpricevitamine.TabIndex = 72
        Me.lblpricevitamine.Text = "$65"
        '
        'lblpricefeedsext
        '
        Me.lblpricefeedsext.AutoSize = True
        Me.lblpricefeedsext.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricefeedsext.ForeColor = System.Drawing.Color.Red
        Me.lblpricefeedsext.Location = New System.Drawing.Point(781, 103)
        Me.lblpricefeedsext.Name = "lblpricefeedsext"
        Me.lblpricefeedsext.Size = New System.Drawing.Size(71, 39)
        Me.lblpricefeedsext.TabIndex = 73
        Me.lblpricefeedsext.Text = "$75"
        '
        'lblpricefacetwo
        '
        Me.lblpricefacetwo.AutoSize = True
        Me.lblpricefacetwo.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricefacetwo.ForeColor = System.Drawing.Color.Red
        Me.lblpricefacetwo.Location = New System.Drawing.Point(484, 168)
        Me.lblpricefacetwo.Name = "lblpricefacetwo"
        Me.lblpricefacetwo.Size = New System.Drawing.Size(89, 39)
        Me.lblpricefacetwo.TabIndex = 74
        Me.lblpricefacetwo.Text = "$130"
        '
        'lblpriceuniqone
        '
        Me.lblpriceuniqone.AutoSize = True
        Me.lblpriceuniqone.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceuniqone.ForeColor = System.Drawing.Color.Red
        Me.lblpriceuniqone.Location = New System.Drawing.Point(484, 118)
        Me.lblpriceuniqone.Name = "lblpriceuniqone"
        Me.lblpriceuniqone.Size = New System.Drawing.Size(89, 39)
        Me.lblpriceuniqone.TabIndex = 75
        Me.lblpriceuniqone.Text = "$200"
        '
        'lblpricedyestintsrevlon
        '
        Me.lblpricedyestintsrevlon.AutoSize = True
        Me.lblpricedyestintsrevlon.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricedyestintsrevlon.ForeColor = System.Drawing.Color.Red
        Me.lblpricedyestintsrevlon.Location = New System.Drawing.Point(484, 69)
        Me.lblpricedyestintsrevlon.Name = "lblpricedyestintsrevlon"
        Me.lblpricedyestintsrevlon.Size = New System.Drawing.Size(71, 39)
        Me.lblpricedyestintsrevlon.TabIndex = 76
        Me.lblpricedyestintsrevlon.Text = "$80"
        '
        'lblpricedyestintspostquan
        '
        Me.lblpricedyestintspostquan.AutoSize = True
        Me.lblpricedyestintspostquan.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricedyestintspostquan.ForeColor = System.Drawing.Color.Red
        Me.lblpricedyestintspostquan.Location = New System.Drawing.Point(470, 317)
        Me.lblpricedyestintspostquan.Name = "lblpricedyestintspostquan"
        Me.lblpricedyestintspostquan.Size = New System.Drawing.Size(71, 39)
        Me.lblpricedyestintspostquan.TabIndex = 77
        Me.lblpricedyestintspostquan.Text = "$70"
        '
        'lblpriceqodtreatment
        '
        Me.lblpriceqodtreatment.AutoSize = True
        Me.lblpriceqodtreatment.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceqodtreatment.ForeColor = System.Drawing.Color.Red
        Me.lblpriceqodtreatment.Location = New System.Drawing.Point(201, 317)
        Me.lblpriceqodtreatment.Name = "lblpriceqodtreatment"
        Me.lblpriceqodtreatment.Size = New System.Drawing.Size(107, 39)
        Me.lblpriceqodtreatment.TabIndex = 78
        Me.lblpriceqodtreatment.Text = "$5000"
        '
        'lblseasals
        '
        Me.lblseasals.AutoSize = True
        Me.lblseasals.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblseasals.ForeColor = System.Drawing.Color.Purple
        Me.lblseasals.Location = New System.Drawing.Point(12, 473)
        Me.lblseasals.Name = "lblseasals"
        Me.lblseasals.Size = New System.Drawing.Size(91, 24)
        Me.lblseasals.TabIndex = 79
        Me.lblseasals.Text = "Sea Sals"
        '
        'lblhandscrub
        '
        Me.lblhandscrub.AutoSize = True
        Me.lblhandscrub.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblhandscrub.ForeColor = System.Drawing.Color.Purple
        Me.lblhandscrub.Location = New System.Drawing.Point(12, 430)
        Me.lblhandscrub.Name = "lblhandscrub"
        Me.lblhandscrub.Size = New System.Drawing.Size(128, 24)
        Me.lblhandscrub.TabIndex = 80
        Me.lblhandscrub.Text = "Hand Scrub"
        '
        'lblpriceseasals
        '
        Me.lblpriceseasals.AutoSize = True
        Me.lblpriceseasals.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceseasals.ForeColor = System.Drawing.Color.Red
        Me.lblpriceseasals.Location = New System.Drawing.Point(201, 460)
        Me.lblpriceseasals.Name = "lblpriceseasals"
        Me.lblpriceseasals.Size = New System.Drawing.Size(89, 39)
        Me.lblpriceseasals.TabIndex = 81
        Me.lblpriceseasals.Text = "$100"
        '
        'lblpricehandscrub
        '
        Me.lblpricehandscrub.AutoSize = True
        Me.lblpricehandscrub.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricehandscrub.ForeColor = System.Drawing.Color.Red
        Me.lblpricehandscrub.Location = New System.Drawing.Point(201, 417)
        Me.lblpricehandscrub.Name = "lblpricehandscrub"
        Me.lblpricehandscrub.Size = New System.Drawing.Size(89, 39)
        Me.lblpricehandscrub.TabIndex = 82
        Me.lblpricehandscrub.Text = "$200"
        '
        'inventory
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(882, 506)
        Me.Controls.Add(Me.lblpricehandscrub)
        Me.Controls.Add(Me.lblpriceseasals)
        Me.Controls.Add(Me.lblhandscrub)
        Me.Controls.Add(Me.lblseasals)
        Me.Controls.Add(Me.lblpriceqodtreatment)
        Me.Controls.Add(Me.lblpricedyestintspostquan)
        Me.Controls.Add(Me.lblpricedyestintsrevlon)
        Me.Controls.Add(Me.lblpriceuniqone)
        Me.Controls.Add(Me.lblpricefacetwo)
        Me.Controls.Add(Me.lblpricefeedsext)
        Me.Controls.Add(Me.lblpricevitamine)
        Me.Controls.Add(Me.lblpricematting)
        Me.Controls.Add(Me.lblpricekeratin)
        Me.Controls.Add(Me.lblpricefinish)
        Me.Controls.Add(Me.lblpriceshampoobyfama)
        Me.Controls.Add(Me.lblvitamine)
        Me.Controls.Add(Me.lblfeedsext)
        Me.Controls.Add(Me.lblmatting)
        Me.Controls.Add(Me.lblkeratin)
        Me.Controls.Add(Me.lblfinish)
        Me.Controls.Add(Me.lbldyestintspostquan)
        Me.Controls.Add(Me.lblqodtreatment)
        Me.Controls.Add(Me.lblshampoobyfama)
        Me.Controls.Add(Me.lblfacetwo)
        Me.Controls.Add(Me.lbldyestintsrevlon)
        Me.Controls.Add(Me.lbluniqone)
        Me.Controls.Add(Me.lblpriceshampoo)
        Me.Controls.Add(Me.lblpricekerasil)
        Me.Controls.Add(Me.lblkerasil)
        Me.Controls.Add(Me.lblshampoogodwell)
        Me.Controls.Add(Me.lblpricedyestints)
        Me.Controls.Add(Me.lbldyestintsgodwell)
        Me.Controls.Add(Me.lblrevlon)
        Me.Controls.Add(Me.lbllabonte)
        Me.Controls.Add(Me.lblpostquan)
        Me.Controls.Add(Me.lblbyfama)
        Me.Controls.Add(Me.lblgodwell)
        Me.Controls.Add(Me.btnhome)
        Me.Name = "inventory"
        Me.Text = "inventory"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnhome As System.Windows.Forms.Button
    Friend WithEvents lblgodwell As System.Windows.Forms.Label
    Friend WithEvents lblbyfama As System.Windows.Forms.Label
    Friend WithEvents lblpostquan As System.Windows.Forms.Label
    Friend WithEvents lbllabonte As System.Windows.Forms.Label
    Friend WithEvents lblrevlon As System.Windows.Forms.Label
    Friend WithEvents lbldyestintsgodwell As System.Windows.Forms.Label
    Friend WithEvents lblpricedyestints As System.Windows.Forms.Label
    Friend WithEvents lblshampoogodwell As System.Windows.Forms.Label
    Friend WithEvents lblkerasil As System.Windows.Forms.Label
    Friend WithEvents lblpricekerasil As System.Windows.Forms.Label
    Friend WithEvents lblpriceshampoo As System.Windows.Forms.Label
    Friend WithEvents lbluniqone As System.Windows.Forms.Label
    Friend WithEvents lbldyestintsrevlon As System.Windows.Forms.Label
    Friend WithEvents lblfacetwo As System.Windows.Forms.Label
    Friend WithEvents lblshampoobyfama As System.Windows.Forms.Label
    Friend WithEvents lblqodtreatment As System.Windows.Forms.Label
    Friend WithEvents lbldyestintspostquan As System.Windows.Forms.Label
    Friend WithEvents lblfinish As System.Windows.Forms.Label
    Friend WithEvents lblkeratin As System.Windows.Forms.Label
    Friend WithEvents lblmatting As System.Windows.Forms.Label
    Friend WithEvents lblfeedsext As System.Windows.Forms.Label
    Friend WithEvents lblvitamine As System.Windows.Forms.Label
    Friend WithEvents lblpriceshampoobyfama As System.Windows.Forms.Label
    Friend WithEvents lblpricefinish As System.Windows.Forms.Label
    Friend WithEvents lblpricekeratin As System.Windows.Forms.Label
    Friend WithEvents lblpricematting As System.Windows.Forms.Label
    Friend WithEvents lblpricevitamine As System.Windows.Forms.Label
    Friend WithEvents lblpricefeedsext As System.Windows.Forms.Label
    Friend WithEvents lblpricefacetwo As System.Windows.Forms.Label
    Friend WithEvents lblpriceuniqone As System.Windows.Forms.Label
    Friend WithEvents lblpricedyestintsrevlon As System.Windows.Forms.Label
    Friend WithEvents lblpricedyestintspostquan As System.Windows.Forms.Label
    Friend WithEvents lblpriceqodtreatment As System.Windows.Forms.Label
    Friend WithEvents lblseasals As System.Windows.Forms.Label
    Friend WithEvents lblhandscrub As System.Windows.Forms.Label
    Friend WithEvents lblpriceseasals As System.Windows.Forms.Label
    Friend WithEvents lblpricehandscrub As System.Windows.Forms.Label
End Class
