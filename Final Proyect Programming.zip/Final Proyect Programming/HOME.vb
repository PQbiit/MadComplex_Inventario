﻿Public Class Home

    Private Sub btnhair_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnhair.Click
        hair_services.Show()
        Me.Hide()
    End Sub

    Private Sub btnfacials_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnfacials.Click
        facials.Show()
        Me.Hide()
    End Sub

    Private Sub btnspa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnspa.Click
        SPA.Show()
        Me.Hide()

    End Sub

    Private Sub btntreat_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btntreat.Click
        treatments.Show()
        Me.Hide
    End Sub

    Private Sub btnaccount_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnaccount.Click
        accounting.Show()
        Me.Hide()
    End Sub

    Private Sub btninventory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btninventory.Click
        inventory.Show()
        Me.Hide()
    End Sub
End Class
