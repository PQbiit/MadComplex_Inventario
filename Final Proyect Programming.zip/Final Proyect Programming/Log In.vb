﻿Public Class Log_In

    Private Sub btnLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLog.Click
        Home.Show()
        Me.Hide()
    End Sub
End Class