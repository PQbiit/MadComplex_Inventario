﻿Public Class hair_services

    Private Sub btnhome_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnhome.Click
        Home.Show()
        Me.Hide()
    End Sub
End Class