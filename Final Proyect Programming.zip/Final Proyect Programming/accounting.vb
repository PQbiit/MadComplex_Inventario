﻿Public Class accounting

    Private Sub accounting_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnhome_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnhome.Click
        Home.Show()
        Me.Hide()
    End Sub
End Class