﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class facials
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblmakeup = New System.Windows.Forms.Label
        Me.lblwaxing = New System.Windows.Forms.Label
        Me.lblpricemakeup = New System.Windows.Forms.Label
        Me.lbleyebrow = New System.Windows.Forms.Label
        Me.lblarm = New System.Windows.Forms.Label
        Me.lblleg = New System.Windows.Forms.Label
        Me.lblarmpit = New System.Windows.Forms.Label
        Me.lblface = New System.Windows.Forms.Label
        Me.lblmustache = New System.Windows.Forms.Label
        Me.lblpricearm = New System.Windows.Forms.Label
        Me.lblpriceleg = New System.Windows.Forms.Label
        Me.lblpricearmpit = New System.Windows.Forms.Label
        Me.lblpriceface = New System.Windows.Forms.Label
        Me.lblpricemustache = New System.Windows.Forms.Label
        Me.lblpriceeyebrow = New System.Windows.Forms.Label
        Me.nudmakeup = New System.Windows.Forms.NumericUpDown
        Me.nudwaxleg = New System.Windows.Forms.NumericUpDown
        Me.nudwaxarmpit = New System.Windows.Forms.NumericUpDown
        Me.nudwaxface = New System.Windows.Forms.NumericUpDown
        Me.undwaxmustache = New System.Windows.Forms.NumericUpDown
        Me.nudwaxeye = New System.Windows.Forms.NumericUpDown
        Me.nudwaxarm = New System.Windows.Forms.NumericUpDown
        Me.btnhome = New System.Windows.Forms.Button
        CType(Me.nudmakeup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudwaxleg, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudwaxarmpit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudwaxface, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.undwaxmustache, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudwaxeye, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudwaxarm, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblmakeup
        '
        Me.lblmakeup.AutoSize = True
        Me.lblmakeup.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmakeup.ForeColor = System.Drawing.Color.Purple
        Me.lblmakeup.Location = New System.Drawing.Point(168, 33)
        Me.lblmakeup.Name = "lblmakeup"
        Me.lblmakeup.Size = New System.Drawing.Size(132, 33)
        Me.lblmakeup.TabIndex = 0
        Me.lblmakeup.Text = "Make Up"
        '
        'lblwaxing
        '
        Me.lblwaxing.AutoSize = True
        Me.lblwaxing.Font = New System.Drawing.Font("Century Gothic", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblwaxing.ForeColor = System.Drawing.Color.Purple
        Me.lblwaxing.Location = New System.Drawing.Point(461, 33)
        Me.lblwaxing.Name = "lblwaxing"
        Me.lblwaxing.Size = New System.Drawing.Size(111, 33)
        Me.lblwaxing.TabIndex = 1
        Me.lblwaxing.Text = "Waxing"
        '
        'lblpricemakeup
        '
        Me.lblpricemakeup.AutoSize = True
        Me.lblpricemakeup.Font = New System.Drawing.Font("Century Gothic", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricemakeup.ForeColor = System.Drawing.Color.Red
        Me.lblpricemakeup.Location = New System.Drawing.Point(177, 77)
        Me.lblpricemakeup.Name = "lblpricemakeup"
        Me.lblpricemakeup.Size = New System.Drawing.Size(104, 44)
        Me.lblpricemakeup.TabIndex = 2
        Me.lblpricemakeup.Text = "$200"
        '
        'lbleyebrow
        '
        Me.lbleyebrow.AutoSize = True
        Me.lbleyebrow.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbleyebrow.ForeColor = System.Drawing.Color.Purple
        Me.lbleyebrow.Location = New System.Drawing.Point(430, 93)
        Me.lbleyebrow.Name = "lbleyebrow"
        Me.lbleyebrow.Size = New System.Drawing.Size(98, 24)
        Me.lbleyebrow.TabIndex = 3
        Me.lbleyebrow.Text = "Eyebrow"
        '
        'lblarm
        '
        Me.lblarm.AutoSize = True
        Me.lblarm.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblarm.ForeColor = System.Drawing.Color.Purple
        Me.lblarm.Location = New System.Drawing.Point(430, 345)
        Me.lblarm.Name = "lblarm"
        Me.lblarm.Size = New System.Drawing.Size(52, 24)
        Me.lblarm.TabIndex = 4
        Me.lblarm.Text = "Arm"
        '
        'lblleg
        '
        Me.lblleg.AutoSize = True
        Me.lblleg.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblleg.ForeColor = System.Drawing.Color.Purple
        Me.lblleg.Location = New System.Drawing.Point(430, 297)
        Me.lblleg.Name = "lblleg"
        Me.lblleg.Size = New System.Drawing.Size(48, 24)
        Me.lblleg.TabIndex = 5
        Me.lblleg.Text = "Leg"
        '
        'lblarmpit
        '
        Me.lblarmpit.AutoSize = True
        Me.lblarmpit.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblarmpit.ForeColor = System.Drawing.Color.Purple
        Me.lblarmpit.Location = New System.Drawing.Point(430, 247)
        Me.lblarmpit.Name = "lblarmpit"
        Me.lblarmpit.Size = New System.Drawing.Size(76, 24)
        Me.lblarmpit.TabIndex = 6
        Me.lblarmpit.Text = "Armpit"
        '
        'lblface
        '
        Me.lblface.AutoSize = True
        Me.lblface.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblface.ForeColor = System.Drawing.Color.Purple
        Me.lblface.Location = New System.Drawing.Point(430, 198)
        Me.lblface.Name = "lblface"
        Me.lblface.Size = New System.Drawing.Size(62, 24)
        Me.lblface.TabIndex = 7
        Me.lblface.Text = "Face"
        '
        'lblmustache
        '
        Me.lblmustache.AutoSize = True
        Me.lblmustache.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblmustache.ForeColor = System.Drawing.Color.Purple
        Me.lblmustache.Location = New System.Drawing.Point(430, 147)
        Me.lblmustache.Name = "lblmustache"
        Me.lblmustache.Size = New System.Drawing.Size(112, 24)
        Me.lblmustache.TabIndex = 8
        Me.lblmustache.Text = "Mustache"
        '
        'lblpricearm
        '
        Me.lblpricearm.AutoSize = True
        Me.lblpricearm.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricearm.ForeColor = System.Drawing.Color.Red
        Me.lblpricearm.Location = New System.Drawing.Point(544, 332)
        Me.lblpricearm.Name = "lblpricearm"
        Me.lblpricearm.Size = New System.Drawing.Size(89, 39)
        Me.lblpricearm.TabIndex = 10
        Me.lblpricearm.Text = "$100"
        '
        'lblpriceleg
        '
        Me.lblpriceleg.AutoSize = True
        Me.lblpriceleg.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceleg.ForeColor = System.Drawing.Color.Red
        Me.lblpriceleg.Location = New System.Drawing.Point(544, 284)
        Me.lblpriceleg.Name = "lblpriceleg"
        Me.lblpriceleg.Size = New System.Drawing.Size(89, 39)
        Me.lblpriceleg.TabIndex = 11
        Me.lblpriceleg.Text = "$140"
        '
        'lblpricearmpit
        '
        Me.lblpricearmpit.AutoSize = True
        Me.lblpricearmpit.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricearmpit.ForeColor = System.Drawing.Color.Red
        Me.lblpricearmpit.Location = New System.Drawing.Point(544, 234)
        Me.lblpricearmpit.Name = "lblpricearmpit"
        Me.lblpricearmpit.Size = New System.Drawing.Size(71, 39)
        Me.lblpricearmpit.TabIndex = 12
        Me.lblpricearmpit.Text = "$50"
        '
        'lblpriceface
        '
        Me.lblpriceface.AutoSize = True
        Me.lblpriceface.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceface.ForeColor = System.Drawing.Color.Red
        Me.lblpriceface.Location = New System.Drawing.Point(544, 185)
        Me.lblpriceface.Name = "lblpriceface"
        Me.lblpriceface.Size = New System.Drawing.Size(89, 39)
        Me.lblpriceface.TabIndex = 13
        Me.lblpriceface.Text = "$100"
        '
        'lblpricemustache
        '
        Me.lblpricemustache.AutoSize = True
        Me.lblpricemustache.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpricemustache.ForeColor = System.Drawing.Color.Red
        Me.lblpricemustache.Location = New System.Drawing.Point(544, 134)
        Me.lblpricemustache.Name = "lblpricemustache"
        Me.lblpricemustache.Size = New System.Drawing.Size(71, 39)
        Me.lblpricemustache.TabIndex = 14
        Me.lblpricemustache.Text = "$30"
        '
        'lblpriceeyebrow
        '
        Me.lblpriceeyebrow.AutoSize = True
        Me.lblpriceeyebrow.Font = New System.Drawing.Font("Century Gothic", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpriceeyebrow.ForeColor = System.Drawing.Color.Red
        Me.lblpriceeyebrow.Location = New System.Drawing.Point(544, 80)
        Me.lblpriceeyebrow.Name = "lblpriceeyebrow"
        Me.lblpriceeyebrow.Size = New System.Drawing.Size(71, 39)
        Me.lblpriceeyebrow.TabIndex = 15
        Me.lblpriceeyebrow.Text = "$50"
        '
        'nudmakeup
        '
        Me.nudmakeup.Location = New System.Drawing.Point(174, 134)
        Me.nudmakeup.Name = "nudmakeup"
        Me.nudmakeup.Size = New System.Drawing.Size(120, 20)
        Me.nudmakeup.TabIndex = 16
        '
        'nudwaxleg
        '
        Me.nudwaxleg.Location = New System.Drawing.Point(675, 301)
        Me.nudwaxleg.Name = "nudwaxleg"
        Me.nudwaxleg.Size = New System.Drawing.Size(120, 20)
        Me.nudwaxleg.TabIndex = 17
        '
        'nudwaxarmpit
        '
        Me.nudwaxarmpit.Location = New System.Drawing.Point(675, 251)
        Me.nudwaxarmpit.Name = "nudwaxarmpit"
        Me.nudwaxarmpit.Size = New System.Drawing.Size(120, 20)
        Me.nudwaxarmpit.TabIndex = 18
        '
        'nudwaxface
        '
        Me.nudwaxface.Location = New System.Drawing.Point(675, 202)
        Me.nudwaxface.Name = "nudwaxface"
        Me.nudwaxface.Size = New System.Drawing.Size(120, 20)
        Me.nudwaxface.TabIndex = 19
        '
        'undwaxmustache
        '
        Me.undwaxmustache.Location = New System.Drawing.Point(675, 151)
        Me.undwaxmustache.Name = "undwaxmustache"
        Me.undwaxmustache.Size = New System.Drawing.Size(120, 20)
        Me.undwaxmustache.TabIndex = 20
        '
        'nudwaxeye
        '
        Me.nudwaxeye.Location = New System.Drawing.Point(675, 97)
        Me.nudwaxeye.Name = "nudwaxeye"
        Me.nudwaxeye.Size = New System.Drawing.Size(120, 20)
        Me.nudwaxeye.TabIndex = 21
        '
        'nudwaxarm
        '
        Me.nudwaxarm.Location = New System.Drawing.Point(675, 349)
        Me.nudwaxarm.Name = "nudwaxarm"
        Me.nudwaxarm.Size = New System.Drawing.Size(120, 20)
        Me.nudwaxarm.TabIndex = 22
        '
        'btnhome
        '
        Me.btnhome.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnhome.ForeColor = System.Drawing.Color.Purple
        Me.btnhome.Location = New System.Drawing.Point(751, 466)
        Me.btnhome.Name = "btnhome"
        Me.btnhome.Size = New System.Drawing.Size(140, 31)
        Me.btnhome.TabIndex = 29
        Me.btnhome.Text = "HOME"
        Me.btnhome.UseVisualStyleBackColor = True
        '
        'facials
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(893, 498)
        Me.Controls.Add(Me.btnhome)
        Me.Controls.Add(Me.nudwaxarm)
        Me.Controls.Add(Me.nudwaxeye)
        Me.Controls.Add(Me.undwaxmustache)
        Me.Controls.Add(Me.nudwaxface)
        Me.Controls.Add(Me.nudwaxarmpit)
        Me.Controls.Add(Me.nudwaxleg)
        Me.Controls.Add(Me.nudmakeup)
        Me.Controls.Add(Me.lblpriceeyebrow)
        Me.Controls.Add(Me.lblpricemustache)
        Me.Controls.Add(Me.lblpriceface)
        Me.Controls.Add(Me.lblpricearmpit)
        Me.Controls.Add(Me.lblpriceleg)
        Me.Controls.Add(Me.lblpricearm)
        Me.Controls.Add(Me.lblmustache)
        Me.Controls.Add(Me.lblface)
        Me.Controls.Add(Me.lblarmpit)
        Me.Controls.Add(Me.lblleg)
        Me.Controls.Add(Me.lblarm)
        Me.Controls.Add(Me.lbleyebrow)
        Me.Controls.Add(Me.lblpricemakeup)
        Me.Controls.Add(Me.lblwaxing)
        Me.Controls.Add(Me.lblmakeup)
        Me.Name = "facials"
        Me.Text = "FACIALS -  Karol´s Beauty Salon"
        CType(Me.nudmakeup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudwaxleg, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudwaxarmpit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudwaxface, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.undwaxmustache, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudwaxeye, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudwaxarm, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblmakeup As System.Windows.Forms.Label
    Friend WithEvents lblwaxing As System.Windows.Forms.Label
    Friend WithEvents lblpricemakeup As System.Windows.Forms.Label
    Friend WithEvents lbleyebrow As System.Windows.Forms.Label
    Friend WithEvents lblarm As System.Windows.Forms.Label
    Friend WithEvents lblleg As System.Windows.Forms.Label
    Friend WithEvents lblarmpit As System.Windows.Forms.Label
    Friend WithEvents lblface As System.Windows.Forms.Label
    Friend WithEvents lblmustache As System.Windows.Forms.Label
    Friend WithEvents lblpricearm As System.Windows.Forms.Label
    Friend WithEvents lblpriceleg As System.Windows.Forms.Label
    Friend WithEvents lblpricearmpit As System.Windows.Forms.Label
    Friend WithEvents lblpriceface As System.Windows.Forms.Label
    Friend WithEvents lblpricemustache As System.Windows.Forms.Label
    Friend WithEvents lblpriceeyebrow As System.Windows.Forms.Label
    Friend WithEvents nudmakeup As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudwaxleg As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudwaxarmpit As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudwaxface As System.Windows.Forms.NumericUpDown
    Friend WithEvents undwaxmustache As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudwaxeye As System.Windows.Forms.NumericUpDown
    Friend WithEvents nudwaxarm As System.Windows.Forms.NumericUpDown
    Friend WithEvents btnhome As System.Windows.Forms.Button
End Class
